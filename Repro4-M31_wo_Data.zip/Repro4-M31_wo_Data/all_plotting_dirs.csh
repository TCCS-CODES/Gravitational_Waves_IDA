#!/bin/csh -fx

### run all plotting jobs 

./plot_M31.csh
