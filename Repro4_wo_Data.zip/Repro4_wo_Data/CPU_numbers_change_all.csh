#!/bin/csh -fx

### run all scanning jobs for all directories

cd Framework-try0005
./change_ncpu_all.csh
cd ..

cd Framework00013
./change_ncpu_all.csh
cd ..

cd GW9_4
./change_ncpu_all.csh
cd ..


cd Framework00013pad
./change_ncpu_all.csh
cd ..
