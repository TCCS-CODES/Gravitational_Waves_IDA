#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul 26 17:02:55 2019

@author: rayabma
"""
import numpy as np
import math 
import sys
import datetime
import time

import matplotlib.pyplot as plt
from matplotlib import rc

from matplotlib import cm, colors
from mpl_toolkits.mplot3d import Axes3D
from collections import deque

def runit():
    ##colors
    ## jet
    ## RdBu
    ## rainbow
    
    
    label = 'J1539'
        
        
    period = 60*3.454885
    finter = 1.0/period
    print(' period of interest in seconds=',period)
    print(' period of interest in minutes=',period/60)
    print(' frequency of interest =',finter)

        
    print('processing start time ----> ',datetime.datetime.now())
    fdisplay = 0
    if len(sys.argv) > 1 :
        fdisplay = int(sys.argv[1])
    print(' fdisplay=',fdisplay,' show plots 0=yes')


    if len(sys.argv) > 2 :
        label = str(sys.argv[2])
    print(' label=',label,' label to plot ')

    dt = 20.0  ### sample interval of IDA sensors in seconds
    fmax = 1.0/(dt * 2.0)
    n1 = 1576800   ### original time axis length
    nfreq = int((n1+1)/2.0)
    df = fmax/(nfreq-1)

    ifnum = int(np.round( finter/df)  )
    print ('index of interest=',ifnum)
    ifnum = math.floor(ifnum/10000)
    ifnum = ifnum * 10000
    ifnum = int(ifnum)
    print(' data needed from Block =',ifnum)


    print(' reading input file 87')
    npzfile = np.load('../GW1987/SBlock_150000.npz')
    fglobe87 = npzfile['cglobe']

    #df = npzfile['df']
    nlat  =   npzfile['nlat']
    nlon  =   npzfile['nlon']
    
    n1  =   npzfile['n1']
    df =    npzfile['df']
    #nfreq = npzfile['nfreq']
    
    print(' n1=',n1)
    print(' df=',df)
    #print(' nfreq=',nfreq)
    
    
    
    print(' nlon=',nlon)
    npolarity =npzfile['npolarity']
    ifzero  =   npzfile['istart']
    print(' ifzero for 1987=',ifzero)
    latgrid =npzfile['latgrid']
    longrid =npzfile['longrid']
    print(' finished extracting input file 87')

    print(' reading input file 86')
    npzfile = np.load('../GW1986/SBlock_150000.npz')
    fglobe86 = npzfile['cglobe']
    ifzero  =   npzfile['istart']
    print(' ifzero for 1986=',ifzero)
    print(' finished extracting input file 86')
    if ( 1 == 1):
        print(' reading input file 85')
        npzfile = np.load('../GW1985/SBlock_150000.npz')
        fglobe85 = npzfile['cglobe']
        ifzero  =   npzfile['istart']
        print(' ifzero for 1985=',ifzero)
        print(' finished extracting input file 85')


        print(' reading input file 84')
        npzfile = np.load('../GW1984/SBlock_150000.npz')
        fglobe84 = npzfile['cglobe']
        ifzero  =   npzfile['istart']
        print(' ifzero for 1984=',ifzero)
        print(' finished extracting input file 84')


        print(' reading input file 17')
        npzfile = np.load('../GW2017/SBlock_150000.npz')
        fglobe17 = npzfile['cglobe']
        ifzero  =   npzfile['istart']
        print(' ifzero for 2017=',ifzero)
        print(' finished extracting input file85')

        df2017 = npzfile['df']



    print(' fglobe87 shape=',np.shape(fglobe87))
    print(' fglobe86 shape=',np.shape(fglobe86))
    if ( 1 == 2):
        print(' fglobe85 shape=',np.shape(fglobe85))
        print(' fglobe84 shape=',np.shape(fglobe84))
        print(' fglobe17 shape=',np.shape(fglobe17))
    nsamp = np.size(fglobe87,axis=3)
    print(' number of samples=',nsamp)

    fzero = (ifzero-1)* df
    fmax = (ifzero+nsamp) * df
    if (fzero > 0):
        periodmax=(1.0/fzero)/60.0
    else:
         periodmax=999999999.0

    periodmin=(1.0/fmax)/60.0
    print(' maximum period=',periodmax,'  minimum period=',periodmin)
    print(' nlat=',nlat,' nlon=',nlon)


    fzero = (ifzero-1)* df

    icnt = 1

    print(' original index=',np.round( finter/df) )
    ifi = int(np.round( finter/df) - ifzero ) +1
    print(' ifzero=',ifzero,' finter/df =',(np.round( finter/df)))

    font = {'family': 'serif',
            'weight': 'normal',
            'size': 8,
            }

    print(' ifzero=',ifzero)
    print(' fzero=',fzero)
    print(' finter=',finter)
    print(' df=',df)
    print(' ifi=',ifi)
    ifisave = ifi

    xa1 = min(longrid)
    xa2 = max(longrid)
    ya1 = min(latgrid)
    ya2 = max(latgrid)
      
    globemap87=np.zeros((nlat,nlon,npolarity))
    globemap86=np.zeros((nlat,nlon,npolarity))
    globemap85=np.zeros((nlat,nlon,npolarity))
    globemap84=np.zeros((nlat,nlon,npolarity))
    globemap17=np.zeros((nlat,nlon,npolarity))

    nplot = 3
    nvplot = 5
    overlap = int(nplot/2.0)
    print(' overlap = ',overlap)

    fig = plt.figure(figsize=[nplot*7.5,nvplot*5.9])
    plt.subplots_adjust(hspace=0.45,wspace=0.5,left=0.2)
    ipcnt = 0
    #for ifi in range(ifisave-1,ifisave+1+1):
    
    print(' center index=',ifisave,ifisave+ifzero)
    print(' center freq = ',(ifisave+ifzero)* df )
    print(' center period = ', 1.0/ (ifisave+ifzero)* df )
    for ifi in range(-overlap,+overlap+1):
  
        print(' ifi=',ifi,' ++++++++++++++++++++++++++++++')
        
 
        ifiorig = ifi + ifzero +ifisave   # take off the extra sample in Blocking
        
        ifiorig87 = ifiorig
        ifiorig86 = ifiorig - 1
        ifiorig85 = ifiorig - 2
        ifiorig84 = ifiorig - 3
        ifiorig17 = ifiorig + 27
        
        ifihere = ifi + ifisave
        print(' ifihere=',ifihere)
        
        





        #print('frequency of interest',freq,' period=',period,
        #    ' should be 321.25 seconds or 5.3542 minutes ')

       

        for ilat in range(nlat) :
            for ilon in range(nlon) :
                for ipol in range(npolarity) :
                    globemap87[ilat,ilon,ipol] = np.abs( fglobe87[ipol,ilon,ilat,ifihere] )
                    globemap86[ilat,ilon,ipol] = np.abs( fglobe86[ipol,ilon,ilat,ifihere-1] )
                    globemap85[ilat,ilon,ipol] = np.abs( fglobe85[ipol,ilon,ilat,ifihere-2] )
                    globemap84[ilat,ilon,ipol] = np.abs( fglobe84[ipol,ilon,ilat,ifihere-3] )
                    globemap17[ilat,ilon,ipol] = np.abs( fglobe17[ipol,ilon,ilat,ifihere+27] )
        fmaxall = 0.0
        fmaxacor = 0.0
        ipoint87 = -1
        for ipol in range(npolarity) :
            fmax= np.max(np.absolute(globemap87[:,:,ipol]))
            if fmax > fmaxall :
                fmaxall = fmax
                ipoint87 = ipol

        fmaxall = 0.0
        fmaxacor = 0.0
        ipoint86 = -1
        for ipol in range(npolarity) :
            fmax= np.max(np.absolute(globemap86[:,:,ipol]))
            if fmax > fmaxall :
                fmaxall = fmax
                ipoint86 = ipol

     
        fmaxall = 0.0
        fmaxacor = 0.0
        ipoint85 = -1
        for ipol in range(npolarity) :
            fmax= np.max(np.absolute(globemap85[:,:,ipol]))
            if fmax > fmaxall :
                fmaxall = fmax
                ipoint85 = ipol

     
        fmaxall = 0.0
        fmaxacor = 0.0
        ipoint84 = -1
        for ipol in range(npolarity) :
            fmax= np.max(np.absolute(globemap84[:,:,ipol]))
            if fmax > fmaxall :
                fmaxall = fmax
                ipoint84 = ipol

     
        fmaxall = 0.0
        fmaxacor = 0.0
        ipoint17 = -1
        for ipol in range(npolarity) :
            fmax= np.max(np.absolute(globemap17[:,:,ipol]))
            if fmax > fmaxall :
                fmaxall = fmax
                ipoint17 = ipol

     
                
       # print(' point87=',ipoint87)
       # print(' point86=',ipoint86)
        #print(' point85=',ipoint85)
       # print(' point84=',ipoint84)
       # print(' point17=',ipoint17)
        ipoint86 = ipoint87
        ipoint85 = ipoint87
        ipoint84 = ipoint87
        #ipoint17 = ipoint87
        

        iflag = 0
        #ishift = int ( nlon * (0 - 1872)/4320 )
        tshiftsec = getoffset(1984)
        ishift = int(tshiftsec/4320 )
        ishift = ishift - 0
        #print (' 1984 shift=',ishift)
        globemapX = shifter(globemap84[:,:,ipoint84],nlat,nlon,ishift)
        globemap84[:,:,ipoint84] = globemapX
                
        #ishift = int(nlon * (3272.0 - 2952)/4320  )
        tshiftsec = getoffset(1985)
        ishift = int(tshiftsec/4320 )
        ishift = ishift - int(nlon * 0.3)
        #print (' 1985 shift=',ishift)
        globemapX = shifter(globemap85[:,:,ipoint85],nlat,nlon,ishift)
        globemap85[:,:,ipoint85] = globemapX
                
        
        #ishift = int(nlon * (2225.0 - 3966)/4320  ) + 20 - int(nlon/2)
        tshiftsec = getoffset(1986)
        ishift = int(tshiftsec/4320 )
        ishift = ishift + int(nlon * 0.3)
        #print (' 1986 shift=',ishift)
        globemapX = shifter(globemap86[:,:,ipoint86],nlat,nlon,ishift)
        globemap86[:,:,ipoint86] = globemapX


        #ishift = int(nlon * (1177.0 - 693)/4320  ) + 20 + int(nlon/2)
        tshiftsec = getoffset(1986)
        ishift = int(tshiftsec/4320 )
        ishift = ishift - 0
        #print (' 1987 shift=',ishift)
        globemapX = shifter(globemap87[:,:,ipoint87],nlat,nlon,ishift)
        globemap87[:,:,ipoint87] = globemapX
        
        
        iflag = 1
        
            
        #plt.figure()
        #plt.imshow( globemap17[:,:,ipoint17] ,cmap='turbo')
                
        
        #ishift = int(nlon * (8618.0 - 693)/(4320*2)  ) + int(nlon/4)
        tshiftsec = getoffset(19201786)
        ishift = int(tshiftsec/8620 )
        ishift = ishift - int(nlon * 0.5)
        #print (' 2017 shift=',ishift)
        globemapX = shifter(globemap17[:,:,ipoint17],nlat,nlon,ishift)
        globemap17[:,:,ipoint17] = globemapX
        
        #plt.figure()
        #plt.imshow( globemap17[:,:,ipoint17] ,cmap='turbo')
        #plt.show()

        
    #    freq = ifi * df + fzero
    #    period = (1.0/freq)/60.0

        rc('font',family='serif')

        if (ipoint87 > -1):


            if ( 1 == 1):
            
                                            
                freq = ifiorig87 * df
                period = (1.0/freq)/60.0
                operiod = period * 2
                speriod = '{:6.6f}'.format(period)
                soperiod = '{:6.6f}'.format(operiod)
                sfreq = '{:0.6f}'.format(freq*1000000.0)
                
                freq = ifiorig87 * df
                period = (1.0/freq)/60.0
                operiod = period * 2
                speriod = '{:6.6f}'.format(period)
                soperiod = '{:6.6f}'.format(operiod)
                sfreq = '{:0.6f}'.format(freq*1000000.0)
                
                ipcnt = ipcnt + 1
                plt.subplot(nvplot,nplot,ipcnt+nplot)
                mmmx = globemap87[:,:,ipoint87]
                #plt.imshow( mmmx ,aspect='auto',extent=(xa1,xa2,ya1,ya2),cmap='Greys')
                plt.imshow( mmmx ,aspect='auto',extent=(xa1,xa2,ya1,ya2),cmap='turbo')
                
     

                ttt = '$\mathbf{J1539}$'+' $\mathbf{1987}$ \n '+'period='+speriod+' min. \n '+\
                'orbital period='+soperiod+' min. \n '+\
                'freq='+sfreq+' MHz \n '+'index='+str(ifiorig)
                #'index=',str(ifiorig)
                
                plt.title(ttt, fontdict=font,fontsize=13)
                plt.xlabel('longitude')
                plt.ylabel('latitude')
                plt.colorbar()

                #print(' icnt=',icnt,' 1987')
                if (icnt == 1):
                    plt.text(-300.0, 140.0, '1987', fontsize=38, \
                        verticalalignment='top',fontweight=500)
                icnt = icnt + 1

                
                                
                freq = ifiorig86 * df
                period = (1.0/freq)/60.0
                operiod = period * 2
                speriod = '{:6.6f}'.format(period)
                soperiod = '{:6.6f}'.format(operiod)
                sfreq = '{:0.6f}'.format(freq*1000000.0)
                
                
                plt.subplot(nvplot,nplot,ipcnt+nplot*2)
                mmmx = globemap86[:,:,ipoint86]
                plt.imshow( mmmx ,aspect='auto',extent=(xa1,xa2,ya1,ya2),cmap='turbo')
                ttt = '$\mathbf{J1539}$'+' $\mathbf{1986}$ \n '+'period='+speriod+' min. \n '+\
                'orbital period='+soperiod+' min. \n '+\
                'freq='+sfreq+' MHz , \n '+'index='+str(ifiorig-1)
                plt.title(ttt, fontdict=font,fontsize=13)
                plt.xlabel('longitude')
                plt.ylabel('latitude')
                plt.colorbar()

                #print(' icnt=',icnt,' 1986')
                if (icnt == 2):
                    plt.text(-300.0, 140.0, '1986', fontsize=38, \
                        verticalalignment='top',fontweight=500)
                icnt = icnt + 1


                                                
                freq = ifiorig85 * df
                period = (1.0/freq)/60.0
                operiod = period * 2
                speriod = '{:6.6f}'.format(period)
                soperiod = '{:6.6f}'.format(operiod)
                sfreq = '{:0.6f}'.format(freq*1000000.0)
                
                plt.subplot(nvplot,nplot,ipcnt+nplot*3)
                mmmx = globemap85[:,:,ipoint85]
                plt.imshow( mmmx ,aspect='auto',extent=(xa1,xa2,ya1,ya2),cmap='turbo')
                ttt = '$\mathbf{J1539}$'+' $\mathbf{1985}$ \n '+'period='+speriod+' min. \n '+\
                'orbital period='+soperiod+' min. \n '+\
                'freq='+sfreq+' MHz , \n '+'index='+str(ifiorig-2)
                plt.title(ttt, fontdict=font,fontsize=13)
                plt.xlabel('longitude')
                plt.ylabel('latitude')
                plt.colorbar()

                #print(' icnt=',icnt,' 1985')
                if (icnt == 3):
                    plt.text(-300.0, 140.0, '1985', fontsize=38, \
                        verticalalignment='top',fontweight=500)
                icnt = icnt + 1


                                             
                freq = ifiorig84 * df
                period = (1.0/freq)/60.0
                operiod = period * 2
                speriod = '{:6.6f}'.format(period)
                soperiod = '{:6.6f}'.format(operiod)
                sfreq = '{:0.6f}'.format(freq*1000000.0)
                
                plt.subplot(nvplot,nplot,ipcnt+nplot*4)
                mmmx = globemap84[:,:,ipoint84]
                plt.imshow( mmmx ,aspect='auto',extent=(xa1,xa2,ya1,ya2),cmap='turbo')
                ttt = '$\mathbf{J1539}$'+' $\mathbf{1984}$ \n '+'period='+speriod+' min. \n '+\
                'orbital period='+soperiod+' min. \n '+\
                'freq='+sfreq+' MHz , \n '+'index='+str(ifiorig-3)
                plt.title(ttt, fontdict=font,fontsize=13)
                plt.xlabel('longitude')
                plt.ylabel('latitude')
                plt.colorbar()

                #print(' icnt=',icnt,' 1984')
                if (icnt == 4):
                    plt.text(-300.0, 140.0, '1984', fontsize=38, \
                        verticalalignment='top',fontweight=500)
                icnt = icnt + 1



 

                                
                freq = ifiorig17 * df
                period = (1.0/freq)/60.0
                operiod = period * 2
                speriod = '{:6.6f}'.format(period)
                soperiod = '{:6.6f}'.format(operiod)
                sfreq = '{:0.6f}'.format(freq*1000000.0)
                ifiorig17 = ifiorig + 27
                
                plt.subplot(nvplot,nplot,ipcnt)
                mmmx = globemap17[:,:,ipoint17]
                plt.imshow( mmmx ,aspect='auto',extent=(xa1,xa2,ya1,ya2),cmap='turbo')
                ttt = '$\mathbf{J1539}$'+' $\mathbf{2017}$ \n '+'period='+speriod+' min. \n '+\
                'orbital period='+soperiod+' min. \n '+\
                'freq='+sfreq+' MHz , \n '+'index='+str(ifiorig17)
                plt.title(ttt, fontdict=font,fontsize=13)
                plt.xlabel('longitude')
                plt.ylabel('latitude')
                plt.colorbar()

                #print(' icnt=',icnt,' 1917')
                if (icnt == 5):
                    plt.text(-300.0, 140.0, '1917', fontsize=38, \
                        verticalalignment='top',fontweight=500)
                icnt = icnt + 1




                

    plotname=label+'_center_v01D.pdf'
    plt.savefig(plotname)
    plotname=label+'_center_v01D.tiff'
    plt.savefig(plotname)

    #print('processing end time ----> ',datetime.datetime.now())
        
    if (fdisplay == 0):
        plt.show()
        
    return

#
        
def shifter(globemap,nlat,nlon,ishift):
 
    #print(' ishift in shifter=',ishift)
    globemlon=np.zeros((nlon))
    Gglobe = np.zeros((nlat,nlon))
    #globemap84=np.zeros((nlat,nlon,npolarity))
    
 
    for ilat in range(nlat) :
    
        for ilon in range(nlon) :
            globemlon[ilon] = np.abs(globemap[ilat,ilon])
                            
        #if (ilat  == 0 and ipol == 0 and iflag == 1):
            #print(' ------globemlon=',globemlon)
                    
        d = deque(globemlon)
        d.rotate(ishift)
        globemlon = list(d)
        #if (ilat  == 0 and ipol == 0 and iflag == 1):
            #print('+++++2nd globemlon=',globemlon)
        
        for ilon in range(nlon) :
            Gglobe[ilat,ilon] = globemlon[ilon]
            
            

           
    return Gglobe
   
   
   #-----------------------------------------------------------------------

    """
    Find the offset in seconds to orient the data with the celestial coordinates
    """
    
    

def getoffset(year):

   #  31558149.504 seconds in one sidereal year



# shift the data so the origin aligns with the Vernal Equinox  --------
#
#  zero right ascension occurs at the Vernal Equinox
#  when the eliptic and celestial equators align,
#  at the first point of aries.  Correcting for the time of
#  the Vernal Equinox aligns terrestrial corridnates with
#  the celestial corridnates.
#  For Vernal Equinox times, see www.timeanddate.com/calendar/seasons.html
#  Convert times to UT, then to seconds, then to samples
#  For example, 1987 Vernal equinox occured at 9:51 PM CST,
#  which was at 3:51 AM UT.  3 hrs = 10800 sec, 51 min = 3060 sec for
#  13860 seconds, which is divided by 10 sec/sample to get 1386 sample offset.
#
#  For the year 1984, the Vernal equinox occured at 10:24 AM GMT, March 20.
#  This is 31 days (January), 29 days (Feb, 2000), and 19 days in March, for
#  79 days, and 10 hours and 24 minutes.  (I don't have the seconds.)
#  (This shouldn't matter too much as long as I'm consistent.)
#
#  For the year 2000, the Vernal equinox occured at 1:35 AM CST, March 20.
#  In Universal time, or London time, this is 7:35 AM, March 20.
#  This is 31 days (January), 29 days (Feb, 2000), and 19 days in March, for
#  79 days, and 7 hours and 35 minutes.  (I don't have the seconds.)
#  (This shouldn't matter too much as long as I'm consistent and its small.)

    reference_year = 2000
    if (year < 2000):
        reference_year = 1984

    idaycnt = 0

    #  count up the days

    for iyear in range(reference_year,year): # go up to, but not including
                                             # the last year.
        idaycnt = idaycnt + 365
        if (iyear % 4 == 0):    ## for leap years ##
            idaycnt = idaycnt + 1

    #print(' total idaycnt=',idaycnt)

    # days from 1 Jan to (but not including) 20 March.
    #    2000 and 1984 were leap years.

    idaycnt = idaycnt + (31 + 29 + 19)  # add January, Feburary,
                                        #and  up to March 19 of year 2000

    #print(' day corrected idaycnt=',idaycnt)

    isecondcnt = idaycnt * 24 * 60 * 60  # convert days to seconds

    #print(' seconds from idaycnt=',isecondcnt)
    #print(' idaycnt=',idaycnt)
    #print(' isecondcnt=',isecondcnt)

    # add the time to 19 March to get the location on
    # 20 March for the Vernal equinox
    # 7 hours, 35 minutes in seconds
    if (year < 2000):
        # for 1984 reference year
        # 10 hours, 23 minutes in seconds
        secondcnt = isecondcnt + (10.0 * 60.0 * 60.0 + 24.0 * 60.0)

    else:
        # for 2000 reference year
        # 7 hours, 35 minutes in seconds
        secondcnt = isecondcnt + (7.0 * 60.0 * 60.0 + 35.0 * 60.0)


    #print(' corrected seconds =',secondcnt)

    # get the number of sidereal days the earth turned
    # offdays is the shift needed to bring the given data back to
    #  the place in the sky where the Vernal Equinox was ---

    siderealday = 86164.0905  # seconds per sideral day
    offdays_tot = secondcnt / siderealday  #offset in sidereal days

     # move back this many seconds to line up with the point of aries,
     # Vernal equinox (0 degrees)
     # time zero is this long after 0 degrees ecliptical longitude

    # clip off the integer years.
    # 365.256363004 is the length of a sidereal year in sidereal days

    offdays = offdays_tot - ( int(offdays_tot/365.256363004) * 365.256363004)
                              # get the excess offset
                              # in days

   #  31558149.504 seconds in one sidereal year
   # lambda_time is the shift from the last Vernal Equinox to time=0 of
   #  the data
   # get lambda_time for this year, cut off the time to be within one year

    lambda_time = secondcnt - (int(secondcnt/31558149.504) * 31558149.504)
               ## secondcnt is in seconds

    # time in seconds for Roemer correction

    #print(' offset in daysc=',offdays)
    #print(' int offset=',int(offdays))

    # find the excess time to turn the earth to match the Vernal equinox
    # this is the offset in seconds from the ecliptical 0 degrees to time=0 of the data

    offdays = offdays - int(offdays)

    print(' offset in a fraction of a sidereal day =',offdays)

    # back off the offset
    # offset in samples

    offset = offdays * (24.0 * 60.0 * 60.0) #convert offset from days to seconds
    print(' offset in seconds =',offset)


    return offset
    
#-----------------------------------------------------------------------

if __name__ == '__main__':
    print(' time start=', time.asctime() )
    runit()
    print(' time end=', time.asctime() )
    print(' @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@=' )





