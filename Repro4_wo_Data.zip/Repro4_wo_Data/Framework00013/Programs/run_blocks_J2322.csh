#!/bin/csh -f

### M31


set j=0

 echo $j
 python3 ../Programs/block_freq_v06.py $j 20000
 mv Block.npz SBlock_${j}.npz

