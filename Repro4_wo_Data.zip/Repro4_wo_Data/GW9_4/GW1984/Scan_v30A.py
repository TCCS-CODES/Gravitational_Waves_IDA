#!/usr/bin/env python3

#
# 11 Feb. 2022 - Ray Abma
#    Reinserted Roemer correction
# 11 Feb. 2020 - ScanE_1984_F04.py - Ray Abma
#    Scaled output by footprint
# GW_1987_VH01  17 Feb. 2022 - ScanE_1984_F04.py - Ray Abma
#    Output both footprint scaled and original data
# GW_1987_VJ01  18 Feb. 2022 - ScanE_1984_F06.py - Ray Abma
#    Included year in output file
#    Passed corrected freqvalues to output file    
# GW_VJ01  24 Feb. 2022 - ScanE_F07.py - Ray Abma
#    Passed only footprint corrected data
#    Always ask for the year
#    Corrected weights
#    Corrected polarity weights
# ScanE_F09.py - 2 March 2022 - Ray Abma
#    Tests    
# ScanE_F10.py - 3 March 2022 - Ray Abma
#    Tests    
# ScanE_F11.py - 5 March 2022 - Ray Abma
#    Added option to map sources in galactic coordinates
# ScanE_F12.py - 15 March 2022 - Ray Abma
#    Removed non-footprint corrected response from output to save space
# ScanE_F13.py - 18 May 2022 - Ray Abma
#    Cleaned up code
# ScanE_F13.py - 19 May 2022 - Ray Abma
#    Fixed rotation direction and set Roemer correction to zero
# ScanE_F15.py - 21 May 2022 - Ray Abma
#    Inserted old location code
# ScanE_F16.py - 7 June 2022 - Ray Abma
#    Set the number of polarities to 9
#    Corrected latgrid and longrid to be radians
# ScanE_F17.py - 7 June 2022 - Ray Abma
#    turned on Roemer correction
# ScanE_F19.py - 14 June 2022 - Ray Abma
#    Fixed Roemer correction
# ScanE_F20.py - 15 June 2022 - Ray Abma
#    Corrected footprint correction
# ScanE_F23 - 28 June 2022 - Ray Abma
#    Corrected angular distance calculation
#    Tried using half the samples
#    Added Roemer correction
# ScanE_F24 - 29 June 2022 - Ray Abma
#    Limited output to a reasonable range of frequencies
#    Set i1min (lower frequency index) to zero
# ScanE_F25 - 1 July 2022 - Ray Abma
#    Corrected scan parameters
#    Hardwired Roemer correction to J0806 location (not yet done)
# Scan_V26 - 6 July 2022 - Ray Abma
#    Removed unused code
# Scan_V30 - 14 July 2022 - Ray Abma
#    Removed acquisition footprint correction


import numpy as np      
from scipy.interpolate import CubicSpline
import matplotlib.pyplot as plt
from matplotlib import rc
import math
import datetime
import sys
import time
import os

from math import (
    sqrt, sin, cos, tan, atan, atan2, asin, acos, radians, pi, copysign,
    degrees
)
from pymeeus.Angle import Angle
from pymeeus.Coordinates import equatorial2ecliptical, angular_separation, relative_position_angle
import pymeeus


from multiprocessing import Pool
from functools import partial


""" Module runit
    set up the main analysis
"""

def runit() :
    
    print('Program name - Scan_V30.py ')

    seconds0 = time.time()

    if len(sys.argv) > 1 :
        ncpu = int(sys.argv[1])
        print( ' ncpu=',ncpu)
    else:
        print(' ncpu must be provided')
        print(' usage "Scan_V30.py  ncpu year"')
        print(' example "Scan_V30.py.py 8 1987"')
        sys.exit(1)  ## error exit


    if len(sys.argv) > 2 :
        year = int(sys.argv[2])
        inyear = year
    else:
        print(' Input year required as a parameter')
        print(' usage "Scan_V30.py.py ncpu year"')
        print(' example "Scan_V30.py.py 8 1987"')
        sys.exit(" *********   Input year required ********")

    ilat1 = -999
    ilat2 =  999
    if len(sys.argv) > 3 :
        ilat1 = int(sys.argv[3])
    if len(sys.argv) > 4 :
        ilat2 = int(sys.argv[4])

    print(' starting latitude = ',ilat1 )
    print(' ending latitude = ',ilat2 )


    if (inyear < 2000):
#         datasets for 1984 to 1987
        if (inyear == 1984):
            print(' importing resp84.npz')
            npzfile = np.load('resp84.npz')
            respin = npzfile['resp84']
            inyear = 1984
        if (inyear == 1985):
            print(' importing resp85.npz')
            npzfile = np.load('resp85.npz')
            respin = npzfile['resp85']
            inyear = 1985
        if (inyear == 1986):
            print(' importing resp86.npz')
            npzfile = np.load('resp86.npz')
            respin = npzfile['resp86']
            inyear = 1986
        if (inyear == 1987):
            print(' importing resp87.npz')
            npzfile = np.load('resp87.npz')
            respin = npzfile['resp87']
            inyear = 1987

    else:

#        datasets for the 2000's datasets
        print(' importing resp_edited.npz')
        npzfile = np.load('resp_edited.npz')
        #print(' importing resp'+str(inyear)+'.npz')
        #npzfile = np.load('resp'+str(inyear)+'.npz')
        respin = npzfile['resp']

    print(' -------- year = ',inyear,'  --------')

    print(' done importing resp')
    (n1in,n2) = np.shape(respin)
    print(' input size =',n1in,n2)

    dt = 10.0  ### sample interval of IDA sensors in seconds
    if (year < 2000):
        dt = 20.0  ## sample interval for the old detectors
#
#  testing code only
#
    subsamp = 1

    if ( subsamp > 1 ):
        print(' input subsampled by a factor of ',subsamp)
        n1save = n1in
        n1in = int(n1save/subsamp)
        resptmp = np.zeros((n1in,n2))
        for i1 in range(n1in):
            for i2 in range(n2):
                resptmp[i1,i2] = respin[i1*2,i2]
        respin = np.copy(resptmp)
        dt = dt * subsamp

        (n1in,n2) = np.shape(respin)
        print(' resampled input size =',n1in,n2)

    # minumum time ---
    if (year > 2000):
        mint = npzfile['mint']
        print( ' mint=',mint)

## respin is the raw edited data

    if (inyear > 2000):
        year = npzfile['year']
        year = int(year)
        year = inyear
        print(' year =',year)
        if (inyear != year):
            print(' year error ****************************************')
            print(' year error ****************************************')
            print(' year error ****************************************')
            print(' year error ****************************************')
            print(' year error ****************************************')
            print(' year error ****************************************')
            print(' year = ',year)
            print(' inyear = ',inyear)
            print(' ****************************************')
            print(' ****************************************')
            print(' ****************************************')
            print(' ****************************************')
            print(' ****************************************')
            sys.exit(1)  ## error exit

        names = npzfile['names']
        print(' names=',names)
    else:
        year = inyear

    print('****************************************')
    print('  year=',year)
    print('****************************************')


   #  31558149.504 seconds in one sidereal year
   #  get a time offset to maintain a consistent starting point in the sky

    offset , lambda_time = getoffset(year)


    toffset = int(offset/dt)  # convert to samples
    print(' toffset in samples =', toffset) # shift this many samples


    #print( ' samples in a year=',n1)
# shift to time of Vernal Equinox
# also transpose the array so the data is the fast axis

    
    print(' max of original respin=',np.max(respin))
    
    
    if (year >= 2000 and year <= 2050):
        lat,long,labels,latgrid,longrid,nlat,nlon,\
        npolarity,deltaangle,gclat,elong = \
        asetup2000(year,names,n2)
    else:
        lat,long,labels,latgrid,longrid,nlat,nlon,\
        npolarity,deltaangle,gclat,elong = \
        asetup(year,n2)


    print(' *****************************')
    print(' number of latitudes =',nlat)
    print(' number of longitudes =',nlon)
    print(' *****************************')

    arun(year,n2,nlat,nlon,\
         lat,long,labels,latgrid,longrid,\
         npolarity,deltaangle,lambda_time,\
         dt, subsamp, ilat1, ilat2, \
         respin, toffset,gclat,elong,ncpu)


    secondsn = time.time() 

    print(' run time (seconds) = ',secondsn-seconds0)
    print(' run time (minutes) = ',(secondsn-seconds0)/60.0)
    print(' run time (hours) = ',(secondsn-seconds0)/(60.0 * 60.0) )
    print(' run time (days) = ',(secondsn-seconds0)/(24 * 60.0 * 60.0) )
    
    return
    
#-----------------------------------------------------------------------

    """
    Find the offset in seconds to orient the data with the celestial coordinates
    """
    
    

def getoffset(year):

   #  31558149.504 seconds in one sidereal year



# shift the data so the origin aligns with the Vernal Equinox  --------
#
#  zero right ascension occurs at the Vernal Equinox
#  when the eliptic and celestial equators align,
#  at the first point of aries.  Correcting for the time of
#  the Vernal Equinox aligns terrestrial corridnates with
#  the celestial corridnates.
#  For Vernal Equinox times, see www.timeanddate.com/calendar/seasons.html
#  Convert times to UT, then to seconds, then to samples
#  For example, 1987 Vernal equinox occured at 9:51 PM CST,
#  which was at 3:51 AM UT.  3 hrs = 10800 sec, 51 min = 3060 sec for
#  13860 seconds, which is divided by 10 sec/sample to get 1386 sample offset.
#
#  For the year 1984, the Vernal equinox occured at 10:24 AM GMT, March 20.
#  This is 31 days (January), 29 days (Feb, 2000), and 19 days in March, for
#  79 days, and 10 hours and 24 minutes.  (I don't have the seconds.)
#  (This shouldn't matter too much as long as I'm consistent.)
#
#  For the year 2000, the Vernal equinox occured at 1:35 AM CST, March 20.
#  In Universal time, or London time, this is 7:35 AM, March 20.
#  This is 31 days (January), 29 days (Feb, 2000), and 19 days in March, for
#  79 days, and 7 hours and 35 minutes.  (I don't have the seconds.)
#  (This shouldn't matter too much as long as I'm consistent and its small.)

    reference_year = 2000
    if (year < 2000):
        reference_year = 1984

    idaycnt = 0

    #  count up the days

    for iyear in range(reference_year,year): # go up to, but not including 
                                             # the last year.
        idaycnt = idaycnt + 365
        if (iyear % 4 == 0):    ## for leap years ##
            idaycnt = idaycnt + 1

    #print(' total idaycnt=',idaycnt)

    # days from 1 Jan to (but not including) 20 March. 
    #    2000 and 1984 were leap years.

    idaycnt = idaycnt + (31 + 29 + 19)  # add January, Feburary, 
                                        #and  up to March 19 of year 2000

    #print(' day corrected idaycnt=',idaycnt)

    isecondcnt = idaycnt * 24 * 60 * 60  # convert days to seconds

    #print(' seconds from idaycnt=',isecondcnt)
    #print(' idaycnt=',idaycnt)
    #print(' isecondcnt=',isecondcnt)

    # add the time to 19 March to get the location on 
    # 20 March for the Vernal equinox
    # 7 hours, 35 minutes in seconds  
    if (year < 2000):
        # for 1984 reference year
        # 10 hours, 23 minutes in seconds
        secondcnt = isecondcnt + (10.0 * 60.0 * 60.0 + 24.0 * 60.0)

    else:
        # for 2000 reference year
        # 7 hours, 35 minutes in seconds
        secondcnt = isecondcnt + (7.0 * 60.0 * 60.0 + 35.0 * 60.0)


    #print(' corrected seconds =',secondcnt)

    # get the number of sidereal days the earth turned
    # offdays is the shift needed to bring the given data back to
    #  the place in the sky where the Vernal Equinox was ---

    siderealday = 86164.0905  # seconds per sideral day
    offdays_tot = secondcnt / siderealday  #offset in sidereal days

     # move back this many seconds to line up with the point of aries, 
     # Vernal equinox (0 degrees)
     # time zero is this long after 0 degrees ecliptical longitude

    # clip off the integer years.  
    # 365.256363004 is the length of a sidereal year in sidereal days

    offdays = offdays_tot - ( int(offdays_tot/365.256363004) * 365.256363004) 
                              # get the excess offset
                              # in days

   #  31558149.504 seconds in one sidereal year
   # lambda_time is the shift from the last Vernal Equinox to time=0 of 
   #  the data
   # get lambda_time for this year, cut off the time to be within one year

    lambda_time = secondcnt - (int(secondcnt/31558149.504) * 31558149.504)  
               ## secondcnt is in seconds

    # time in seconds for Roemer correction

    #print(' offset in daysc=',offdays)
    #print(' int offset=',int(offdays))

    # find the excess time to turn the earth to match the Vernal equinox
    # this is the offset in seconds from the ecliptical 0 degrees to time=0 of the data

    offdays = offdays - int(offdays)

    print(' offset in a fraction of a sidereal day =',offdays)

    # back off the offset
    # offset in samples

    offset = offdays * (24.0 * 60.0 * 60.0) #convert offset from days to seconds
    print(' offset in seconds =',offset)


    return offset , lambda_time
    
#-----------------------------------------------------------------------

    """
    Rotate the responses and Fourier transform
    """
""" Module arun
    process each point of the grid (right ascension and declination)
"""

def arun(year,n2,nlat,nlon,\
     lat,long,labels,latgrid,longrid,\
     npolarity,deltaangle,lambda_time,\
     dt, subsamp, ilat1, ilat2, \
     respin, toffset,gclat,elong,ncpu):
    
    """
    Rotate the responses and Fourier transform
    """
    
    
    print('npolarity =',npolarity)
    print(' nlat =',nlat,' nlon =',nlon)
    
    print('processing start time ----> ',datetime.datetime.now())
    

# set up frequency lengths

    (n1in,n2) = np.shape(respin)

    # set the length of the input data to be a fixed length to ensure that the
    # frequency values are common to all the years (fixed for < 2000 and fixed for > 2000
    # add 48 hours of samples to allow for shifts
    
    n1 = int( 366 * 24 * 60 * 60/dt)  + int(86400/dt)
    
    ### lengths for testing ###
    #n1in =3020 * 4
    #n1 = n1in + int(86400/dt)
    ####################

    df = 1.0/( n1 * dt )
    print( ' n1=',n1)
    print( ' dt=',dt)
    freqvalues = np.fft.rfftfreq(n1, dt)

    print(' df calculated =',df,'  df from rfftfreq=',\
            freqvalues[2]-freqvalues[1])

    df = freqvalues[2]-freqvalues[1]


#   These values correspond to those in denoisefft.py 
    highfreq = 1.0/150.0  # shortest period is 150 seconds
    lowfreq =  1.0/3000.0  # longest period is 3000 seconds

    ncfreq = np.shape(freqvalues)[0]

    for i1 in range(ncfreq):
        i1max = i1
        if (freqvalues[i1] > highfreq):
            break
    print(' max Fourier coef at ', i1max,' is ',freqvalues[i1max],' Hz')

    #for i1 in range(ncfreq):
        #i1min = i1
        #if (freqvalues[i1] > lowfreq):
            #break

    i1min = 0
    print(' min Fourier coef at ', i1min,' is ',freqvalues[i1min],' Hz')



    resp = np.zeros((n2,n1))
    slice = np.zeros((nlat,nlon))

    print(' ncfreq=',ncfreq)
    freq = ncfreq * df 
    period = (1.0/freq)/60.0

    print(' minimum period = ',period,' minutes')
    print(' maximum frequency = ',freq)
    print(' frequency increment = ',df)
    print(' frequency increment = ',df*1000000000,' nano-Hz')
    print (' fglobe buffer size=',ncfreq*npolarity*nlon)

    vorbit = 30000 # meters/second
    c = 299792458 # speed of light,  meters/second
    
   ############################
    #toffset = 100  ### positive number pushs event forward in time
   ############################

    print(' toffset=',toffset)


######### shift and transpose respin to make resp #######################
#  shift all samples to make them line up with celestial zero

    for i2 in range(n2):
        for i1 in range(n1in-toffset):
            resp[i2,i1+toffset] = respin[i1,i2]

#########################################################################

    livestn = np.zeros(n2)
    for istn in range(n2):
        all_zeros = np.count_nonzero(respin[:,istn])
        if (all_zeros > 0):
            livestn[istn]  = 1.0

    if (year < 2000):

        #  live stations
        station_list1 = [1,2,3,5,7,8,10,11,12,13,15,16,17,19,20,22,23,24]
        #  best stations
        station_list2 = [2,3,5,7,10,11,12,13,15,16,20,23]
        #  one station
        station_list3 = [20,23]
        #  all stations
        station_list4 = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,
                         19,20,21,22,23,24]
        station_listX = [4,23]

        station_list = station_list2

##########    test    ##############
        #station_list = station_listX
##########    test    ##############


        print(' station list=',station_list)

        for istn in range(n2):
            livestn[istn]  = 0.0
            for istn2 in station_list:
                if (istn2-1 == istn):
                    livestn[istn]  = 1.0
    
    print(' live stations =',livestn)
        
    ncpua = os.cpu_count()
    print(' number of cpus available=',ncpua)
    print(' number of cpus to be used = ',ncpu)

    pltarray = np.zeros((nlat,nlon))
    footprintarray = np.zeros((nlat,nlon))
    footprintarrayM = np.zeros((nlat,nlon,80))



#        -- interpolation factor for Roemer correction

    if ( year < 2000):
        rsupersample = 10
    else:
        rsupersample = 6


            

    ### loop over source longitude and latitude from the table

#--- restart here if needed -----

    if (ilat1 < 0):
        ilat1 = 0
    if (ilat2 > nlat):
        ilat2 = nlat - 1
    print(' starting latitude reset to  = ',ilat1 )
    print(' ending latitude reset to  = ',ilat2 )

    for ilat in range( int(ilat1), int(ilat2+1) ):   

        print('Starting ilat=',ilat+1,' of ',nlat,'       ',datetime.datetime.now())

        fglobe=np.zeros((npolarity,nlon,ncfreq),dtype=np.cdouble)
        inxarray = np.zeros([2,nlon],dtype=int)

        icnt = 0
        for ilon in range( nlon ) :

            inxarray[0,icnt] = ilat
            inxarray[1,icnt] = ilon
            icnt = icnt + 1

        dumarray = np.zeros(icnt,dtype=int)
        cnttable = dumarray.astype(np.int64)

        icnt = 0
        for ilon in range(nlon) :
            cnttable[icnt] = icnt
            icnt = icnt + 1

            
###  --- multi-cpu option ####
        if ( 1 == 1):
        
            with Pool(ncpu) as pp:

                longworkx = partial(longwork, \
                            resp,rsupersample,npolarity, \
                            longrid, latgrid, \
                            inxarray,df, \
                            lambda_time,  \
                            gclat,elong,dt,n1,n2,nlon,nlat,\
                            livestn,year)

                q = pp.map(longworkx,cnttable)
        
            icnt= 0
            for ilon in range(nlon):

                globe,mxrm,wfootprint,deltapol =\
                  q[icnt]

                pltarray[ilat,ilon] = mxrm
                footprintarray[ilat,ilon] = wfootprint

                icnt = icnt + 1
        
                for ipol in range(npolarity):
                    rtemp = globe[ipol,:]
                    ftemp = np.fft.rfft(rtemp)
                    fglobe[ipol,ilon,0:ncfreq] = ftemp[0:ncfreq]
                
                # end of ipol loop

            # end of ilon loop

###  --- single cpu option ####
        else:
            
            icnt= 0
            for ilon in range(nlon):

                globe,mxrm,wfootprint,\
                             longwork(resp,rsupersample,npolarity, \
                             longrid, latgrid, \
                             inxarray,df, \
                             lambda_time,  \
                             gclat,elong,\
                            dt,n1,n2,nlon,nlat,\
                            livestn,year,icnt)

                icnt = icnt + 1
        
                pltarray[ilat,ilon] = mxrm
                footprintarray[ilat,ilon] = wfootprint

                for ipol in range(npolarity):
                    rtemp = globe[ipol,:]
                    ftemp = np.fft.rfft(rtemp)
                    fglobe[ipol,ilon,0:ncfreq] = ftemp[0:ncfreq]

                # end of ipol loop
            # end of ilon loop
        
### --- save the results ####

        n1outfreq = i1max - i1min + 1
        fglobecorrected=np.zeros((npolarity,nlon,n1outfreq),dtype=np.cdouble)
        for ilon in range(nlon):
            for ipol in range(npolarity):
                ## why did this mess up the output?
                #xfootprint = footprintarray[ilat,ilon] 
                fglobecorrected[ipol,ilon,i1min:i1max] =\
                         fglobe[ipol,ilon,0:i1max-i1min]

        outfile = 'partial_ilat'+str(ilat)
        #print('Saving partial file =',outfile, '    ',datetime.datetime.now() )

        np.savez(outfile,\
             npolarity=npolarity,\
             fglobecorrected=fglobecorrected,\
             i1min=i1min, i1max=i1max, \
             #fglobe=fglobe,\
             nlat=nlat,nlon=nlon,\
             dt=dt,df=df,\
             n1=n1, n2=n2,ncfreq=ncfreq,\
             outfile=outfile,
             lat=lat,long=long, labels=labels,\
             longrid=longrid, latgrid=latgrid, \
             gclat=gclat,elong=elong, freq=freq, \
             year=year, deltapol=deltapol,\
             freqvalues=freqvalues,\
             subsamp=subsamp,\
             footprintarray=footprintarray,\
             footprintarrayM=footprintarrayM,pltarray=pltarray )

        #slice[ilat,:] = np.abs(fglobe[1,:,1000])


    # end of ilat loop


    
    
    print('processing end time ----> ',datetime.datetime.now())

##### diagnostic plots #####
    #pltroemer(pltarray,year)
    pltfootprint(footprintarray,year)
    #plttempplot(tempplot,year)
    #pltsky(slice,year,'Freq_slice')
    #plt.show()

    return




#-----------------------------------------------------------------------
        
""" Module longwork - parallel processing of longitude loop 
    inner loops
    Each call does one potential source position at a single ilat and ilon.
"""

def longwork(resp,rsupersample,npolarity, \
            longrid, latgrid, \
             inxarray, df, \
             lambda_time,  \
             gclat,elong,\
             dt,n1,n2,nlon,nlat,\
             livestn, year ,icount) :
    
    """
    parallel processing of longitude loop
    """
    
    ## source position ##

    ilat =      inxarray[0,icount]
    ilon =      inxarray[1,icount]




# *************************************************
# *************************************************
# *************************************************
# This is a comparison test between the original equatorial coords and galactic coords
# *************************************************
# *************************************************
# *************************************************
    if ( 1 == 2):

 ####    convert galactic coordinates to equatorial coordinates   ####
        long_tmp = longrid[ilon]
        lat_tmp= latgrid[ilat] 

        longitude = Angle(long_tmp,radians=True)
        latitude = Angle(lat_tmp,radians=True)

        ra, dec = pymeeus.Coordinates.galactic2equatorial(longitude, latitude)

        theta_s = float(ra) * math.pi/180.0
        phi_s = float(dec) * math.pi/180.0

    else:

 ####      plot results in equatorial coordinates ####

        phi_s = latgrid[ilat] 
        theta_s = longrid[ilon] 

        #  used below
        a = phi_s
        cosa = np.cos(a)
        sina = np.sin(a)

   

    deltapol = math.pi/( 2.0 * ( npolarity - 1.0))
    globe = np.zeros((npolarity,n1))

    if (year < 2000):
        iskip = 10    ##  increment between calculated weight values
    else:
        iskip = 20

#########################################################################

###  We need this for the Roemer correction
### ---- setup ----
    # from Meeus, Astronomical Algorithms - Chapter 13, eqns 13.1 and 13.2
    # convert from RA (theta_s) and Dec (phi_s) to ecliptic coordinates
    # using the pymeeus routines

    #dec = Angle(phi_s,radians=True)
    #ra = Angle(theta_s,radians=True)
    #dec = Angle(phi_s,radians=True)
    #ra = Angle(theta_s,radians=True)
    #lambda_sx, beta_sx = equatorial2ecliptical(ra, dec, epsilon) 
    ## ecliptical longitude 
    ## and latitude out

    ### fix the Roemer correction for J0806 ###

    dec_J0806 = Angle(8,6,22.95)
    ra_H0806 = Angle(15, 27, 31.0)
    epsilon = Angle(23.4392911)
    lambda_sx, beta_sx = equatorial2ecliptical(ra_H0806, dec_J0806, epsilon) 

    lambda_s = float(lambda_sx) * math.pi/180.0
    beta_s = float(beta_sx) * math.pi/180.0

    cosbeta = np.cos(beta_s)


    #  Roemer correction from Maggiore, Gravitational Waves, Vol. 1
    Omega = 2.0 * math.pi /( 365.256363004 * 24.0 * 60.0 * 60.0 )

#########################################################################

    yindex = np.zeros((n1))   # QC array
    x_shift_index = np.zeros((n1))

    vorbit = 30000 # meters/second
    c = 299792458 # speed of light,  meters/second
    
    wfootprint = 0.0


    for i1 in range(0,n1):   
        t = i1*dt
        # Roemer correction (Gravitational Waves, Maggiore)
        # 499.0048 from Meeus

#       t is the time of the sample (starting from midnight at the beginning of the year)
#       lambda_time - is the time to line the correction up with the Vernal Equinox
#       lambda_s - is the ecliptic latitude

        tRoemer=499.0048*np.cos(Omega*(t-lambda_time)-lambda_s ) * cosbeta
        
####  turn off the Roemer correction until we can get true positions ###
##############################################################################
        tRoemer= 0.0
##############################################################################

        tshifted = t - tRoemer   # time in seconds
        isamp = int( rsupersample * tshifted/dt )  # time in samples
        if (isamp >= 0 and isamp < rsupersample * n1):
            x_shift_index[i1] = isamp 
        yindex[i1] = tRoemer   # QC array

        

    mxrm = np.amax(yindex)  # QC value for Roemer correction
    respR = np.zeros((n1))
  
    for i2 in range(n2) :
        if (livestn[i2] != 0.0 ):

##      -- interpolate the input --     ###
            resptmp = resp[i2,:]
            ftemp = np.fft.rfft(resptmp)
            n1y = np.shape(ftemp)[0]
            n1x = n1y * rsupersample
            fxtemp = np.zeros(n1x,dtype=np.cdouble)
            fxtemp[0:n1y] = ftemp[:]
            resp_temp = np.real( np.fft.irfft(fxtemp) )

#        -- apply the Roemer correction

            for iii in range(n1):
                jjj = int(x_shift_index[iii])
                respR[iii] = resp_temp[jjj]

###############################################################


#        -- receiver latitude and longitude 
            phi_r = gclat[i2] # in radians
            theta_r = elong[i2]  # in radians

            poldirvals = np.zeros((npolarity,n1))
            WSindex =  np.zeros((n1))
            WSvalue =  np.zeros((n1))
            count_index  =  np.zeros((n1))

            WScnt = 0
    
            for i1 in range(0,n1):   
                t = i1*dt

                count_index[i1] = i1
    
                if (i1%iskip == 0):

                      # directional weight array
                      # eta is the angle change with the earth's rotation


                    eta = t * 2.0*math.pi/ 86164.09053083288
                    #  86164.09053083288 is rotation period 
                    #  of the earth in seconds
                    
                    # correct eta to the lowest angle
                    while eta > 2.0 * math.pi :
                        eta = eta - 2.0 * math.pi

                    thetaprime = theta_r + eta


                    C = thetaprime - theta_s
                    cosC = np.cos(C)
                    sinC = np.sin(C)

                    # used below
                    b=phi_r
                    sinb = np.sin(b)
                    cosb = np.cos(b)

                    ## see the cosine rule for spherical triangles
                    dist = np.arccos(sinb * sina + cosb * cosa * cosC)

                    # this doesn't matter much since we scan all the angles
                    az = np.arctan2(sinC, ( cosa*np.tan(b) ) - ( sina*cosC ) )
                    nu = dist
                    xpsi = az

                    # polarity analysis
                    WS2 = np.abs(np.sin(nu))**2

                    for ipol in range(npolarity):
                        polangle = ipol * deltapol
                        psip = xpsi + polangle
                        resp2 = (1+ 0.5 * np.sin( 2.0 * psip) )

                        poldirvals[ipol,WScnt] =  resp2

                    # end of ipol loop

                    WSindex[WScnt] = i1
                    WSvalue[WScnt] = WS2

                    WScnt = WScnt + 1


##############################################################################
    

                ## end of if (i1%iskip == 0) loop
            # end of i1 loop

#       --- interpolate the weights ---


            cs = CubicSpline(WSindex[0:WScnt], WSvalue[0:WScnt])
            Weights = cs(count_index)

            polweights = np.zeros((npolarity,n1))
            for ipol in range(npolarity):
                ppp = np.zeros((WScnt))
                ppp = poldirvals[ipol,:]
                cs = CubicSpline(WSindex[0:WScnt],ppp[0:WScnt])
                ppp2 = cs(count_index)
                polweights[ipol,:] = ppp2


#    -- apply the weights to the data ---


            for i1 in range(0,n1):
                wfootprint = wfootprint + Weights[i1]
                for ipol in range(npolarity):
                    A2 = respR[i1] * Weights[i1] * polweights[ipol,i1]
                    globe[ipol,i1] = globe[ipol,i1] + A2
    
            # end of i1 loop
        # end of if (if (livestn[i2] != 0.0 ):
    # end of i2 loop
        
    return globe,mxrm,wfootprint,deltapol
            
#-----------------------------------------------------------------------
def pltroemer(pltarray,year) :

    """
    plot the Roemer correction
    """


    #print(' Saving partial file')
    outfile = 'plotaa'
    print('Saving plot data file =',outfile, '    ',datetime.datetime.now() )

    np.savez(outfile, pltarray=pltarray)

    print('Saved plot file =',outfile, '    ',datetime.datetime.now() )



    (nlon,nlat) = np.shape(pltarray)
    print(' nlon = ',nlon)
    print(' nlat = ',nlat)
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='mollweide')

    lon = np.linspace(-np.pi, np.pi,nlat)
    lat = np.linspace(-np.pi/2., np.pi/2.,nlon)
    Lon,Lat = np.meshgrid(lon,lat)

    im = ax.pcolormesh(Lon,Lat,pltarray, cmap=plt.cm.jet,shading='auto')
    fig.colorbar(im)
    plt.title('Roemer correction')

    plotname='Roemer_correction'+str(year)+'-resp.pdf'
    plt.savefig(plotname)


    #plt.show()



    return
    
    
#-----------------------------------------------------------------------
#-----------------------------------------------------------------------
def plttempplot(pltarray,year) :

    """
    plot the acquisition footprint
    """


    fig = plt.figure()
    plt.plot(pltarray)
    plt.title('tempplot_'+str(year))
    plotname='C_tempplot'+str(year)+'-resp.tiff'
    plt.savefig(plotname)

    #plt.show()

    return


#-----------------------------------------------------------------------
def pltfootprint(pltarray,year) :

    """
    plot the acquisition footprint
    """


    print(' Saving footprint file')
    outfile = 'footprint'+str(year)+'_X'
    print('Saving plot data file =',outfile, '    ',datetime.datetime.now() )

    np.savez(outfile, pltarray=pltarray)

    print('Saved plot file =',outfile, '    ',datetime.datetime.now() )



    (nlon,nlat) = np.shape(pltarray)
    print(' nlon = ',nlon)
    print(' nlat = ',nlat)
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='mollweide')

    lon = np.linspace(-np.pi, np.pi,nlat)
    lat = np.linspace(-np.pi/2., np.pi/2.,nlon)
    #Lon,Lat = np.meshgrid(lon,lat)

    #im = ax.pcolormesh(Lon,Lat,pltarray, cmap=plt.cm.jet,shading='auto')
    im = ax.pcolormesh(lon,lat,pltarray, cmap=plt.cm.jet,shading='auto')
    fig.colorbar(im)
    plt.title('Footprint')

    plotname='footprint'+str(year)+'-resp.pdf'
    plt.savefig(plotname)


    #plt.show()
    
    return


            
#-----------------------------------------------------------------------

def pltsky(pltarray,year,title) :

    """
    plot the acquisition footprint
    """

    (nlat,nlon) = np.shape(pltarray)
    print(' nlat = ',nlat)
    print(' nlon = ',nlon)
    fig = plt.figure()
    #ax = fig.add_subplot(111, projection='mollweide')

    #lat = np.linspace(-np.pi/2.0, np.pi/2.0,nlat)
    #lon = np.linspace(-np.pi, np.pi,nlon)
    #im = ax.pcolormesh(lon,lat,pltarray, cmap=plt.cm.jet,shading='auto')
    #fig.colorbar(im)
    plt.imshow(pltarray)
    plt.title(title)

    plotname='ABsky'+str(year)+'_'+title+'-newresp.pdf'
    plt.savefig(plotname)


    plt.show()



#-----------------------------------------------------------------------


""" Module asetup - setup 
    set locations of stations
"""

def asetup2000(year,names,n2) :
    
    """
    Separate the overlapping sources.
    niter is the number of iterations to use to solve the separation.
    """

##
## get the the longitude and latitude of the uniformly spaced grid
## 4 degree incrments
## now 6 degree increments


    global gclat
    global elong

    diag = 0
    
## set the number of correlations to test
    deltaangle = 6.0
    npolarity = 9
    
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

###  get station locations and names
                     
    lat,long, labels = stations2000(n2,names)


#   convert lat and longs to radians
    gclat = np.zeros(n2)
    elong = np.zeros(n2)

    for i in range(n2) :
        s = lat[i]/np.abs(lat[i])    ## sign of the latitude
        w = 0.0      
        if lat[i] != -90 :  # for stations not at the South Pole
            w = long[i]/np.abs(long[i])

#     ### for the 2000s, the latitudes and longitudes are in degrees
        gclat[i] = lat[i]
        elong[i] = long[i]
        


##### QC for plotting the station locations ####
    if 1 == 2 :
        fig = plt.figure()
        plt.plot(elong,gclat,'ro')
        plt.title('IDA Station Locations - Degrees')
        for ii in range(n2):
            plt.text(elong[ii],gclat[ii],labels[ii])
        plt.show()

    for i in range(n2) :   ## convert to radians
            gclat[i] = gclat[i] * math.pi /180.0
            elong[i] = elong[i] * math.pi /180.0
       
    nlat = round(180.0/deltaangle)+1
    nlon = round(360.0/deltaangle)+1
   
    latgrid = np.zeros(nlat)
    longrid = np.zeros(nlon)
   
    for ilat in range(nlat):
        latitude = ilat * deltaangle - 90.0 + 0.5
        latitude = (latitude / 180.0 ) * np.pi
        latgrid[ilat] = latitude
       
    for ilon in range(nlon):
        longitude = ilon * deltaangle - 180.0 + 0.5
        longitude = (longitude / 180.0 ) * np.pi
        longrid[ilon] = longitude


    return lat,long,labels,latgrid,longrid,nlat,nlon,\
npolarity,deltaangle,gclat,elong


## end of asetup2000
#-----------------------------------------------------------------------


""" Module asetup - setup 
    set locations of stations
"""

def asetup(year,n2) :
    
    """
    Separate the overlapping sources.
    niter is the number of iterations to use to solve the separation.
    """

##
## get the the longitude and latitude of the uniformly spaced grid
## 4 degree incrments
## now 6 degree increments


    global gclat
    global elong

    diag = 0
    
## set the number of correlations to test
    deltaangle = 6.0
    npolarity = 9
    
    print(' n2=',n2)
    print(' ')

    

###  get station locations and names
                     
    lat,long, labels = stations()


#   convert lat and longs to radians
    gclat = np.zeros(n2)
    elong = np.zeros(n2)

    for i in range(n2) :
        s = lat[i,0]/np.abs(lat[i,0])    ## sign of the latitude
        w = 0.0      
        if lat[i,0] != -90 :  # for stations not at the South Pole
            w = long[i,0]/np.abs(long[i,0])

        gclat[i] = lat[i,0]+ s* (( lat[i,1] +   ( lat[i,2] /60.0 ) )/ 60.0)
        elong[i] = long[i,0]+ w*((long[i,1] +   (long[i,2]/60.0  ) )/ 60.0)
        


######  QC plot of station locations   ######
    #if 1 == 1 :
        #fig = plt.figure()
        #plt.plot(elong,gclat,'ro')
        #plt.title('IDA Station Locations - Degrees')
        #for ii in range(n2):
        #    plt.text(elong[ii],gclat[ii],labels[ii])
        #plt.show()

    for i in range(n2) :   ## convert to radians
            gclat[i] = gclat[i] * math.pi /180.0
            elong[i] = elong[i] * math.pi /180.0
       
    nlat = round(180.0/deltaangle)+1
    nlon = round(360.0/deltaangle)+1
   
    latgrid = np.zeros(nlat)
    longrid = np.zeros(nlon)
   
    for ilat in range(nlat):
        latitude = ilat * deltaangle - 90.0 + 0.5
        latitude = (latitude / 180.0 ) * np.pi
        latgrid[ilat] = latitude
       
    for ilon in range(nlon):
        longitude = ilon * deltaangle - 180.0 + 0.5
        longitude = (longitude / 180.0 ) * np.pi
        longrid[ilon] = longitude


    return lat,long,labels,latgrid,longrid,nlat,nlon,\
npolarity,deltaangle,gclat,elong


## end of asetup
#-----------------------------------------------------------------------


""" Module stations 
    set locations and labels of stations
"""

def stations2000(n2,names) :
    
    """
    Fill in the locations (lat, long) of the IDA stations.
    """

    lat = np.zeros(n2)
    long = np.zeros(n2)

    stnlocs = [
    ['AAK',	42.6375,	74.4942	 ],
    ['ABKT',	37.9304,	58.1189	 ],
    ['ABPO',	-19.018,	47.229	 ],
    ['ALE',	82.5033,	-62.35	 ],
    ['ARTI',	56.3879,	58.3849	 ],
    ['ARU',	56.4302,	58.5625	 ],
    ['ASCN',	-7.9327,	-14.3601	], 
    ['BFO',	48.3301,	8.3296	 ],
    ['BORG',	64.7474,	-21.3268	], 
    ['BORK',	53.0461,	70.3184	 ],
    ['BRVK',	53.0581,	70.2828	 ],
    ['CMLA',	37.7637,	-25.5243	], 
    ['COCO',	-12.1901,	96.8349	 ],
    ['DGAR',	-7.4121,	72.4525	 ],
    ['EFI',	-51.6753,	-58.0637	 ],
    ['ERM',	42.015,	143.1572	], 
    ['ESK',	55.3167,	-3.205	 ],
    ['FFC',	54.725,	-101.9783	], 
    ['GAR',	39.0052,	70.3328	 ],
    ['HOPE',	-54.2836,	-36.4879	 ],
    ['IASL',	34.946201,	-106.456703	 ],
    ['IBFO',	48.331902,	8.3311	 ],
    ['JTS',	10.2908,	-84.9525	 ],
    ['KAPI',	-5.0142,	119.7517	 ],
    ['KDAK',	57.7828,	-152.5835	 ],
    ['KIV',	43.9562,	42.6888	 ],
    ['KURK',	50.7154,	78.6202	 ],
    ['KWAJ',	8.8019,	167.613	 ],
    ['KWJN',	9.2873,	167.5369	], 
    ['LVZ',	67.8979,	34.6514	 ],
    ['MBAR',	-0.6019,	30.7382	 ],
    ['MSEY',	-4.6737,	55.4792	 ],
    ['MSVF',	-17.7448,	178.0528	 ],
    ['NIL',	33.6506,	73.2686	 ],
    ['NNA',	-11.9875,	-76.8422	 ],
    ['NRIL',	69.5049,	88.4414	 ],
    ['NVS',	54.8404,	83.2346	 ],
    ['OBN',	55.1146,	36.5674	 ],
    ['PALK',	7.2728,	80.7022	 ],
    ['PFO',	33.6092,	-116.4553	], 
    ['RAYN',	23.5225,	45.5032	 ],
    ['RPN',	-27.1267,	-109.3344	 ],
    ['SACV',	14.9702,	-23.6085	 ],
    ['SHEL',	-15.9594,	-5.7455	 ],
    ['SIMI',	38.6585,	69.0083	 ],
    ['SUR',	-32.3797,	20.8117	 ],
    ['TAU',	-42.9099,	147.3204	], 
    ['TLY',	51.6807,	103.6438	 ],
    ['UOSS',	24.9453,	56.2042	 ],
    ['WRAB',	-19.9336,	134.36	 ],
    ['XBFO',	48.3301,	8.3296	 ],
    ['XPF',	33.6092,	-116.4533	],
    ['XPFO',	33.6107,	-116.4555	 ]
    ]
    
    labels=["     "]*n2

    for i in range(0,n2):
        for j in range(53):
            if ( names[i] == stnlocs[j][0]):
                lat[i] = stnlocs[j][1]
                long[i] = stnlocs[j][2]
                labels[i] = names[i]
        if (labels[i] == "     "):
            print(' station not found ------')
            print(' station not found ------')
            print(' station not found ------')
            print(' station not found ------')
            print(' station not found ------')
            print(' names =',names)
            print(' stnlocs  =',stnlocs[:,0])
            quit()

    print(' labels = ',labels)




##### QC plot of station locations  #####
    if 1 == 2 :
        fig = plt.figure()
        #ax = fig.add_subplot(111, projection='mollweide')
        tlong = long[:,0]
        tlat = lat[:,0]
        plt.plot(tlong,tlat,'ro')
        plt.title('IDA Station Locations - Degrees')
        for ii in range(24):
            xx = float(long[ii,0])
            yy = float(lat[ii,0])
            plt.text(xx,yy,labels[ii])
        plt.show()




    return lat, long, labels

#  end of stations2000
#-----------------------------------------------------------------------
#-----------------------------------------------------------------------


""" Module stations 
    set locations and labels of stations
"""

def stations() :
    
    """
    Fill in the locations (lat, long) of the IDA stations.
    """
    
    ### station locations and names

    lat=np.array([[82,29,0],
    [-15,39,50], 
    [40,2,25],
    [-35,19,15], 
    [64,51,36],
    [-27,9,29], 
    [42,0,54], 
    [55,19,0], 
    [39,0,0], 
    [13,32,18], 
    [44,38,16],
    [21,25,24], 
    [25,8,54],
    [-77,50,57],
    [-11,59,15], 
    [33,36,33],
    [-21,12,45],
    [-4,36,54], 
    [18,6,34],
    [-90,0,0], 
    [45,16,45],
    [-32,22,47],
    [-35,1,57],
    [-21,11,44]])


    long = np.array([[ -62,24,0], 
    [-47,54,12], 
    [116,10,30], 
    [148,59,55],
    [-147,50,6],
    [-109,26,4], 
    [143,9,26], 
    [-3,12,18], 
    [70,19,0], 
    [144,54,42], 
    [-63,35,30],
    [-158,0,54], 
    [102,44,49],
    [166,40,2],
    [-76,50,32],
    [-116,27,19],
    [-159,46,24],
    [ 55,29,27], 
    [-66,9,0], 
    [0,0,0], 
    [ 4,32,31], 
    [ 20,48,42],
    [ 138,34,41],
    [ 55,34,40]])
   

    labels=['1 ALE','2 BDF','3 BJT','4 CAN','5 CMO','6 EIC','7 ERM','8 ESK','9 GAR','10 GUA','11 HAL','12 KIP','13 KMY','14 MCM','15 NNA','16 PFO','17 RAR','18 SEY','19 SJG','20 SPA','21 SSB','22 SUR','23  TWO','24 PCR']


    if 1 == 2 :
        fig = plt.figure()
        #ax = fig.add_subplot(111, projection='mollweide')
        tlong = long[:,0]
        tlat = lat[:,0]
        plt.plot(tlong,tlat,'ro')
        plt.title('IDA Station Locations - Degrees')
        for ii in range(24):
            xx = float(long[ii,0])
            yy = float(lat[ii,0])
            plt.text(xx,yy,labels[ii])
        plt.show()


    return lat, long, labels

#-----------------------------------------------------------------------

if __name__ == '__main__':
    print(' time start=', time.asctime() )
    runit()
    print(' time end=', time.asctime() )
    print(' @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@=' )
