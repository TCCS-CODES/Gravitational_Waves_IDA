#!/bin/csh -fx

### run all jobs for all directories




./setup-data.csh

./all_scan_dirs.csh

./all_blocking_dirs.csh

./all_plotting_dirs.csh


