#!/bin/csh -fx

### run all scanning jobs for this directory

cd GW2017
source runscan.txt
cd ..

cd GW1987
source runscan.txt

cd ..
cd GW1986
source runscan.txt

cd ..
cd GW1985
source runscan.txt

cd ..
cd GW1984
source runscan.txt

cd ..

