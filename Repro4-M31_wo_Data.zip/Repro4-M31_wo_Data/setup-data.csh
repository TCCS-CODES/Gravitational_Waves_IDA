#!/bin/csh -fx

### run all data prep jobs for all directories


cd GW9_4

cp ../GW-DATA/resp84.npz GW1984/.
cp ../GW-DATA/resp85.npz GW1985/.
cp ../GW-DATA/resp86.npz GW1986/.
cp ../GW-DATA/resp87.npz GW1987/.
cp ../GW-DATA/resp_edited.npz GW2017/.

cd ..
