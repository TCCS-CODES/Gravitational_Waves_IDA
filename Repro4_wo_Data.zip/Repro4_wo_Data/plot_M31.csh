#!/bin/csh -fx

### run all scanning jobs for all directories

cd GW9_4

cd M31-UCXB1_plots

./M31_center_v17BD.py 1

cp *.pdf ../../Figures

cd ..

cd ..

