#!/bin/csh -fx

### run all scanning jobs for all directories

cd Framework00013pad

cd J1539-plots

./J1539_center.py 1

cp *.pdf ../../Figures

cd ..

cd ..

