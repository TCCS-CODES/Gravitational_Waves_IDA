#!/bin/csh -f

### change number of cpus used from 16 to 4 's/16/4/g'

cd GW2017
sed -i '' 's/16/4/g' runscan.txt
cat runscan.txt

cd ..
cd GW1987
sed -i '' 's/16/4/g' runscan.txt
cd ..

cd GW1986
sed -i '' 's/16/4/g' runscan.txt
cd ..

cd GW1985
sed -i '' 's/16/4/g' runscan.txt
cd ..

cd GW1984
sed -i '' 's/16/4/g' runscan.txt
cd ..

