#!/bin/csh -f

### M31


set j=150000
while ($j < 150001)
 echo $j
 python3 ../Programs/block_freq_v06.py $j 5000
 mv Block.npz SBlock_${j}.npz
 @ j = $j + 2000
end
