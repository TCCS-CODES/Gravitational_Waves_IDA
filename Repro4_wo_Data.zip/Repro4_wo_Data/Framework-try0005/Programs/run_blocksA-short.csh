#!/bin/csh -f

### 90000 includes J0806

set j = 97000
while ($j < 97001)
 echo $j
 python3 ../Programs/block_freq_v04-short.py $j
 mv Block.npz SBlock_${j}_short.npz
 @ j = $j + 2000
end
