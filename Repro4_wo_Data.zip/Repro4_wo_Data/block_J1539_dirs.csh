#!/bin/csh -fx

### run all J1539 blocking jobs for all directories


cd Framework00013pad

cd GW1984
../Programs/run_blocks_J1539.csh
cd ..

cd GW1985
../Programs/run_blocks_J1539.csh
cd ..

cd GW1986
../Programs/run_blocks_J1539.csh
cd ..

cd GW1987
../Programs/run_blocks_J1539.csh
cd ..

cd GW2017
../Programs/run_blocks_J1539.csh
cd ..

cd ..
