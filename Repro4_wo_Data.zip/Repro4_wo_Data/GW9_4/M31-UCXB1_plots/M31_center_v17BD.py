#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul 26 17:02:55 2019

@author: rayabma
"""
import numpy as np
import math 
import sys
import datetime

import matplotlib.pyplot as plt
from matplotlib import rc

from matplotlib import cm, colors
from mpl_toolkits.mplot3d import Axes3D


print('processing start time ----> ',datetime.datetime.now())
fdisplay = 0
if len(sys.argv) > 1 :
    fdisplay = int(sys.argv[1])
print(' fdisplay=',fdisplay,' show plots 0=yes')




label = 'M31 UCXB-1'


dt = 20.0  ### sample interval of IDA sensors in seconds



print(' reading input file 87')
npzfile = np.load('../GW1987/SBlock_90000.npz')
fglobe87 = npzfile['cglobe']


df = npzfile['df']
print('extracted df=',df)
nlat  =   npzfile['nlat']
nlon  =   npzfile['nlon']
npolarity =npzfile['npolarity']
ifzero  =   npzfile['istart']

indx87 = 47293 + ifzero

print(' ifzero for 1987=',ifzero)
latgrid =npzfile['latgrid']
longrid =npzfile['longrid']
print(' finished extracting input file 87')

print(' reading input file 86')
npzfile = np.load('../GW1986/SBlock_90000.npz')
fglobe86 = npzfile['cglobe']
ifzero  =   npzfile['istart']
print(' ifzero for 1986=',ifzero)
print(' finished extracting input file 86')


indx86 = 47292 + ifzero


print(' reading input file 85')
npzfile = np.load('../GW1985/SBlock_90000.npz')
fglobe85 = npzfile['cglobe']
ifzero  =   npzfile['istart']

indx85 = 47291 + ifzero

print(' ifzero for 1985=',ifzero)
print(' finished extracting input file85')


print(' reading input file 84')
npzfile = np.load('../GW1984/SBlock_90000.npz')
fglobe84 = npzfile['cglobe']
ifzero  =   npzfile['istart']

indx84 = 47290 + ifzero

print(' ifzero for 1984=',ifzero)
print(' finished extracting input file84')


print(' reading input file 2017')
npzfile = np.load('../GW2017/SBlock_90000.npz')
indx17 = 137268
indx17 = 47323 + ifzero
fglobe17 = npzfile['cglobe']
ifzero2017  =   npzfile['istart']


print(' ifzero for 2017=',ifzero)
print(' finished extracting input file85')

df2017 = npzfile['df']
print(' ########## df2017=',df2017)
print(' ########## df=',df)

print(' fglobe87 shape=',np.shape(fglobe87))
print(' fglobe86 shape=',np.shape(fglobe86))
if ( 1 == 2):
    print(' fglobe85 shape=',np.shape(fglobe85))
    print(' fglobe84 shape=',np.shape(fglobe84))
print(' fglobe17 shape=',np.shape(fglobe17))
nsamp = np.size(fglobe87,axis=3)
print(' number of samples=',nsamp)

indx87 = indx87 - ifzero
indx86 = indx86 - ifzero
indx85 = indx85 - ifzero
indx84 = indx84 - ifzero
indx17 = indx17 - ifzero





fzero = ifzero * df
fzero2017 = ifzero * df2017

icnt = 1

font = {'family': 'serif',
        'weight': 'normal',
        'size': 8,
        }
print(' +++++++++++++++++++++++++++++')
print(' ifzero2017=',ifzero2017)
print(' fzero2017=',fzero2017)
print(' ifzero=',ifzero)
print(' fzero=',fzero)


print(' df=',df)

xa1 = min(longrid)
xa2 = max(longrid)
ya1 = min(latgrid)
ya2 = max(latgrid)
  
globemap87=np.zeros((nlat,nlon,npolarity))
globemap86=np.zeros((nlat,nlon,npolarity))
globemap85=np.zeros((nlat,nlon,npolarity))
globemap84=np.zeros((nlat,nlon,npolarity))
globemap17=np.zeros((nlat,nlon,npolarity))

nplot = 3
nvplot = 5
overlap = int(nplot/2.0)

fig = plt.figure(figsize=[nplot*7.5,nvplot*5.9])
plt.subplots_adjust(hspace=0.45,wspace=0.5,left=0.2)
ipcnt = 0
#for ifi in range(ifisave-1,ifisave+1+1):
for ifi in range(-overlap,+overlap+1):



    for ilat in range(nlat) :
        for ilon in range(nlon) :
            for ipol in range(npolarity) :
                globemap87[ilat,ilon,ipol] = np.abs( fglobe87[ipol,ilon,ilat,ifi+indx87] )
                globemap86[ilat,ilon,ipol] = np.abs( fglobe86[ipol,ilon,ilat,ifi+indx86] )
                globemap85[ilat,ilon,ipol] = np.abs( fglobe85[ipol,ilon,ilat,ifi+indx85] )
                globemap84[ilat,ilon,ipol] = np.abs( fglobe84[ipol,ilon,ilat,ifi+indx84] )
                globemap17[ilat,ilon,ipol] = np.abs( fglobe17[ipol,ilon,ilat,ifi+indx17] )
    fmaxall = 0.0
    fmaxacor = 0.0
    ipoint87 = -1
    for ipol in range(npolarity) :
        fmax= np.max(np.absolute(globemap87[:,:,ipol]))
        if fmax > fmaxall :
            fmaxall = fmax
            ipoint87 = ipol

    fmaxall = 0.0
    fmaxacor = 0.0
    ipoint86 = -1
    for ipol in range(npolarity) :
        fmax= np.max(np.absolute(globemap86[:,:,ipol]))
        if fmax > fmaxall :
            fmaxall = fmax
            ipoint86 = ipol

 
    fmaxall = 0.0
    fmaxacor = 0.0
    ipoint85 = -1
    for ipol in range(npolarity) :
        fmax= np.max(np.absolute(globemap85[:,:,ipol]))
        if fmax > fmaxall :
            fmaxall = fmax
            ipoint85 = ipol

 
    fmaxall = 0.0
    fmaxacor = 0.0
    ipoint84 = -1
    for ipol in range(npolarity) :
        fmax= np.max(np.absolute(globemap84[:,:,ipol]))
        if fmax > fmaxall :
            fmaxall = fmax
            ipoint84 = ipol

 
    fmaxall = 0.0
    fmaxacor = 0.0
    ipoint17 = -1
    for ipol in range(npolarity) :
        fmax= np.max(np.absolute(globemap17[:,:,ipol]))
        if fmax > fmaxall :
            fmaxall = fmax
            ipoint17 = ipol

 
            
    #print(' point87=',ipoint87)
    #print(' point86=',ipoint86)
    #print(' point85=',ipoint85)
    #print(' point84=',ipoint84)
    #print(' point17=',ipoint17)
    ipoint86 = ipoint87
    ipoint85 = ipoint87
    ipoint84 = ipoint87
    ipoint17 = ipoint87

    


    rc('font',family='serif')

    if (ipoint87 > -1):



        if ( 1 == 1):
        
            freq = (ifi+indx87+ifzero) * df
            sfreq = '{:0.6f}'.format(freq*1000000.0)
            period = (1.0/freq)/60.0
            speriod = '{:6.6f}'.format(period)
            operiod = period*2.0
            soperiod = '{:6.6f}'.format(operiod)
            ifiorig87 = ifi+indx87+ifzero

            ipcnt = ipcnt + 1
            plt.subplot(nvplot,nplot,ipcnt+nplot)
            mmmx = globemap87[:,:,ipoint87]

            plt.imshow( mmmx ,aspect='auto',extent=(xa1,xa2,ya1,ya2),cmap='jet')
            

            
            ttt = '$\mathbf{M31 UCXB-1}$'+' $\mathbf{1987}$ \n '+'period='+speriod+' min. \n '+\
                'orbital period='+soperiod+' \n '\
            'freq='+sfreq+' MHz \n '+'index='+str(ifiorig87)
            
            plt.title(ttt, fontdict=font,fontsize=13)
            plt.xlabel('longitude')
            plt.ylabel('latitude')
            plt.colorbar()

            #print(' icnt=',icnt,' 1987')
            if (icnt == 1):
                plt.text(-300.0, 140.0, '1987', fontsize=38, \
                    verticalalignment='top',fontweight=500)
            icnt = icnt + 1



            freq = (ifi+indx86+ifzero) * df
            sfreq = '{:0.6f}'.format(freq*1000000.0)
            period = (1.0/freq)/60.0
            speriod = '{:6.6f}'.format(period)
            operiod = period*2.0
            soperiod = '{:6.6f}'.format(operiod)
            ifiorig86 = ifi+indx86+ifzero

            
            plt.subplot(nvplot,nplot,ipcnt+nplot*2)
            mmmx = globemap86[:,:,ipoint86]
            plt.imshow( mmmx ,aspect='auto',extent=(xa1,xa2,ya1,ya2),cmap='jet')
            ttt = '$\mathbf{M31 UCXB-1}$'+' $\mathbf{1986}$ \n '+'period='+speriod+' min. \n '+\
                'orbital period='+soperiod+' \n '\
            'freq='+sfreq+' MHz , \n '+'index='+str(ifiorig86)
            plt.title(ttt, fontdict=font,fontsize=13)
            plt.xlabel('longitude')
            plt.ylabel('latitude')
            plt.colorbar()

            #print(' icnt=',icnt,' 1986')
            if (icnt == 2):
                plt.text(-300.0, 140.0, '1986', fontsize=38, \
                    verticalalignment='top',fontweight=500)
            icnt = icnt + 1


            freq = (ifi+indx85+ifzero) * df

            sfreq = '{:0.6f}'.format(freq*1000000.0)
            period = (1.0/freq)/60.0
            speriod = '{:6.6f}'.format(period)
            operiod = period*2.0
            soperiod = '{:6.6f}'.format(operiod)
            ifiorig85 = ifi+indx85+ifzero

            plt.subplot(nvplot,nplot,ipcnt+nplot*3)
            mmmx = globemap85[:,:,ipoint85]
            plt.imshow( mmmx ,aspect='auto',extent=(xa1,xa2,ya1,ya2),cmap='jet')
            ttt = '$\mathbf{M31 UCXB-1}$'+' $\mathbf{1985}$ \n '+'period='+speriod+' min. \n '+\
                'orbital period='+soperiod+' \n '\
            'freq='+sfreq+' MHz , \n '+'index='+str(ifiorig85)
            plt.title(ttt, fontdict=font,fontsize=13)
            plt.xlabel('longitude')
            plt.ylabel('latitude')
            plt.colorbar()

            #print(' icnt=',icnt,' 1985')
            if (icnt == 3):
                plt.text(-300.0, 140.0, '1985', fontsize=38, \
                    verticalalignment='top',fontweight=500)
            icnt = icnt + 1





            freq = (ifi+indx84+ifzero) * df

            sfreq = '{:0.6f}'.format(freq*1000000.0)
            period = (1.0/freq)/60.0
            speriod = '{:6.6f}'.format(period)
            operiod = period*2.0
            soperiod = '{:6.6f}'.format(operiod)
            ifiorig84 = ifi+indx84+ifzero

            plt.subplot(nvplot,nplot,ipcnt+nplot*4)
            mmmx = globemap84[:,:,ipoint84]
            plt.imshow( mmmx ,aspect='auto',extent=(xa1,xa2,ya1,ya2),cmap='jet')
            ttt = '$\mathbf{M31 UCXB-1}$'+' $\mathbf{1984}$ \n '+'period='+speriod+' min. \n '+\
                'orbital period='+soperiod+' \n '\
            'freq='+sfreq+' MHz , \n '+'index='+str(ifiorig84)
            plt.title(ttt, fontdict=font,fontsize=13)
            plt.xlabel('longitude')
            plt.ylabel('latitude')
            plt.colorbar()

            #print(' icnt=',icnt,' 1984')
            if (icnt == 4):
                plt.text(-300.0, 140.0, '1984', fontsize=38, \
                    verticalalignment='top',fontweight=500)
                    
            icnt = icnt + 1


            freq = (ifi+indx17+ifzero) * df

            sfreq = '{:0.6f}'.format(freq*1000000.0)
            period = (1.0/freq)/60.0
            speriod = '{:6.6f}'.format(period)
            operiod = period*2.0
            soperiod = '{:6.6f}'.format(operiod)
            ifiorig17 = ifi+indx17+ifzero
            
            plt.subplot(nvplot,nplot,ipcnt)
            mmmx = globemap17[:,:,ipoint17]
            plt.imshow( mmmx ,aspect='auto',extent=(xa1,xa2,ya1,ya2),cmap='jet')
            ttt = '$\mathbf{M31 UCXB-1}$'+' $\mathbf{2017}$ \n '+'period='+speriod+' min. \n '+\
                'orbital period='+soperiod+' \n '\
            'freq='+sfreq+' MHz , \n '+'index='+str(ifiorig17)
            plt.title(ttt, fontdict=font,fontsize=13)
            plt.xlabel('longitude')
            plt.ylabel('latitude')
            plt.colorbar()

            #print(' icnt=',icnt,' 2017')
            if (icnt == 5):
                plt.text(-300.0, 140.0, '1917', fontsize=38, \
                    verticalalignment='top',fontweight=500)
            icnt = icnt + 1








            

plotname='M31_center_v17BD.pdf'
plt.savefig(plotname)
plotname='M31_center_v17BD.tiff'
plt.savefig(plotname)

print('processing end time ----> ',datetime.datetime.now())
    
if (fdisplay == 0):
    plt.show()


#



