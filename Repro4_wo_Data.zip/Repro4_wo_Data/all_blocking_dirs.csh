#!/bin/csh -fx

### run all scanning jobs for all directories

./block_J0806_dirsE.csh

./block_J1539_dirs.csh

./block_J2243_dirs.csh

./block_M31_dirs.csh
