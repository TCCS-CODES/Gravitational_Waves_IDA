#!/bin/csh -fx

### run all scanning jobs for all directories

cd Framework-try0005
./scan_all.csh
cd ..

cd Framework00013
./scan_all.csh
cd ..

cd GW9_4
./scan_all.csh
cd ..


cd Framework00013pad
./scan_all.csh
cd ..
