#!/bin/csh -fx

### run all plotting jobs 

./plot_synthetics.csh

./plot_J0806.csh

./plot_J1539.csh

./plot_J2243.csh

./plot_M31.csh
