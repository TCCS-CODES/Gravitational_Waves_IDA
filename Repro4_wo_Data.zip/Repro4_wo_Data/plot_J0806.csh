#!/bin/csh -fx

### run all scanning jobs for all directories

cd Framework-try0005

cd J0806-plotsB

./J0806_center_v08E.py 1
./J0806_center_v08DX.py 1
./J0806_horizontal_v08DX.py 1

cp *.pdf ../../Figures

cd ..

cd ..

