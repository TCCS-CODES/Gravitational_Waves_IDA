#!/bin/csh -fx

### run all scanning jobs for all directories


cd GW9_4
./scan_all.csh
cd ..
