#!/bin/csh -fx

### run all scanning jobs for all directories

cd Framework00013pad

cd J2243-plots

./J2243_combined-center-padded.py 1

cp *.pdf ../../Figures

cd ..

cd ..

