#!/bin/csh -f

### J2243 


set j=119400
while ($j < 119401)
 echo $j
 python3 ../Programs/block_freq_v06.py $j 5000
 mv Block.npz SBlock_${j}.npz
 @ j = $j + 5000
end
