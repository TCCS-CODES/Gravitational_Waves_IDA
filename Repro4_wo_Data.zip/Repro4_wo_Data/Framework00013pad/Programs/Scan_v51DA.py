#!/usr/bin/env python3

#
# 11 Feb. 2022 - Ray Abma

# Scan_v50 - 31 December - Ray Abma
#   Shortened output
# Scan_v51 - 14 February 2026 - Ray Abma
#   Allowed padding of input traces to decrease frequency increment
# Scan_51D.py
# removed start time corrections (Do this in plots)
# removed unused code

import numpy as np
from scipy.interpolate import CubicSpline
import matplotlib.pyplot as plt
from matplotlib import rc
import math
import datetime
import sys
import time
import os
from pymeeus.Epoch import Epoch
from pymeeus.Angle import Angle

from math import (
    sqrt, sin, cos, tan, atan, atan2, asin, acos, radians, pi, copysign,
    degrees
)
from pymeeus.Angle import Angle
from pymeeus.Coordinates import equatorial2ecliptical, angular_separation, relative_position_angle
import pymeeus


from multiprocessing import Pool
from functools import partial


""" Module runit
    set up the main analysis
"""

def runit() :
    
    print('Program name - Scan_V51D.py - Removed time corrections - long padding')
    
    padding = 1

    seconds0 = time.time()

    if len(sys.argv) > 1 :
        ncpu = int(sys.argv[1])
        print( ' ncpu=',ncpu)
    else:
        print(' ncpu must be provided')
        print(' usage "Scan_V31.py  ncpu year"')
        print(' example "Scan_V31.py.py 8 1987"')
        sys.exit(1)  ## error exit


    if len(sys.argv) > 2 :
        year = int(sys.argv[2])
        inyear = year
    else:
        print(' Input year required as a parameter')
        print(' usage "Scan_V31.py ncpu year"')
        print(' example "Scan_V31.py 8 1987"')
        sys.exit(" *********   Input year required ********")


### restart code

    ilat1 = -999
    ilat2 =  999
    if len(sys.argv) > 3 :
        ilat1 = int(sys.argv[3])
    if len(sys.argv) > 4 :
        ilat2 = int(sys.argv[4])

    print(' starting latitude = ',ilat1 )
    print(' ending latitude = ',ilat2 )


    if (inyear < 2000):
#         datasets for 1984 to 1987
        if (inyear == 1984):
            print(' importing resp84.npz')
            npzfile = np.load('resp84.npz')
            respin = npzfile['resp84']
        if (inyear == 1985):
            print(' importing resp85.npz')
            npzfile = np.load('resp85.npz')
            respin = npzfile['resp85']
        if (inyear == 1986):
            print(' importing resp86.npz')
            npzfile = np.load('resp86.npz')
            respin = npzfile['resp86']
        if (inyear == 1987):
            print(' importing resp87.npz')
            npzfile = np.load('resp87.npz')
            respin = npzfile['resp87']

    else:

#        datasets for the 2000's datasets
        print(' importing resp_edited.npz')
        npzfile = np.load('resp_edited.npz')
        #print(' importing resp'+str(inyear)+'.npz')
        #npzfile = np.load('resp'+str(inyear)+'.npz')
        respin = npzfile['resp']



    print(' -------- year = ',inyear,'  --------')

    print(' done importing resp')
    (n1in,n2) = np.shape(respin)
    print(' input size =',n1in,n2)

    dt = 10.0  ### sample interval of IDA sensors in seconds
    if (year < 2000):
        dt = 20.0  ## sample interval for the old detectors
#



    # minumum time ---
    if (year > 2000):
        mint = npzfile['mint']
        print( ' mint=',mint)

## respin is the raw edited data

    if (inyear > 2000):
        year = npzfile['year']
        year = int(year)
        year = inyear
        print(' year =',year)
        if (inyear != year):
            print(' year error ****************************************')
            print(' year error ****************************************')
            print(' year error ****************************************')
            print(' year error ****************************************')
            print(' year error ****************************************')
            print(' year error ****************************************')
            print(' year = ',year)
            print(' inyear = ',inyear)
            print(' ****************************************')
            print(' ****************************************')
            print(' ****************************************')
            print(' ****************************************')
            print(' ****************************************')
            sys.exit(1)  ## error exit

        names = npzfile['names']
        print(' names=',names)
    else:
        year = inyear

    print('****************************************')
    print('  year=',year)
    print('****************************************')


    
    if (year < 2000):
        dt = 20.0
    else:
        dt = 10.0
        

## removing start time corrections (placed in plots)
# It looks like the start times for the various years vary
    toffset = 0


    print(' toffset (samples)=',toffset)



    
    print(' max of original respin=',np.max(respin))
    
    
    if (year >= 2000 and year <= 2050):
        lat,long,labels,latgrid,longrid,nlat,nlon,\
        npolarity,deltaangle,gclat,elong = \
        asetup2000(year,names,n2)
    else:
        lat,long,labels,latgrid,longrid,nlat,nlon,\
        npolarity,deltaangle,gclat,elong = \
        asetup(year,n2)


    print(' *****************************')
    print(' number of latitudes =',nlat)
    print(' number of longitudes =',nlon)
    print(' *****************************')

    arun(year,n2,nlat,nlon,padding,\
         lat,long,labels,latgrid,longrid,\
         npolarity,deltaangle,\
         dt, ilat1, ilat2, \
         respin, toffset,gclat,elong,ncpu)


    secondsn = time.time() 

    print(' run time (seconds) = ',secondsn-seconds0)
    print(' run time (minutes) = ',(secondsn-seconds0)/60.0)
    print(' run time (hours) = ',(secondsn-seconds0)/(60.0 * 60.0) )
    print(' run time (days) = ',(secondsn-seconds0)/(24 * 60.0 * 60.0) )
    
    return
    

    


#-----------------------------------------------------------------------

    

    """
    Rotate the responses and Fourier transform
    """
""" Module arun
    process each point of the grid (right ascension and declination)
"""

def arun(year,n2,nlat,nlon,padding,\
     lat,long,labels,latgrid,longrid,\
     npolarity,deltaangle,\
     dt,  ilat1, ilat2, \
     respin, toffset,gclat,elong,ncpu):
    
    """
    Rotate the responses and Fourier transform
    """
    
    
    print('npolarity =',npolarity)
    print(' nlat =',nlat,' nlon =',nlon)
    
    print('processing start time ----> ',datetime.datetime.now())
    

# set up frequency lengths

    (n1in,n2) = np.shape(respin)

    # set the length of the input data to be a fixed length to ensure that the
    # frequency values are common to all the years (fixed for < 2000 and fixed for > 2000
    # add 48 hours of samples to allow for shifts
    
    ####  zero padding ###
    n1 = padding * int( 366 * 24 * 60 * 60/dt)  + int(86400/dt)
    #n1 = padding * int( 366 * 24 * 60 * 60/dt)
    #n1 = n1in
    #############
    
    ### lengths for testing ###
    #n1in =3020 * 4
    #n1 = n1in + int(86400/dt)
    ####################

    df = 1.0/( n1 * dt )
    print( ' n1=',n1)
    print( ' dt=',dt)
    freqvalues = np.fft.rfftfreq(n1, dt)

    print(' df calculated =',df,'  df from rfftfreq=',\
            freqvalues[2]-freqvalues[1])

    df = freqvalues[2]-freqvalues[1]
### should I do this?
#   These values correspond to those in denoisefft.py
    highfreq = 1.0/150.0  # shortest period is 150 seconds
    lowfreq =  1.0/3000.0  # longest period is 3000 seconds

    ncfreq = np.shape(freqvalues)[0]

    for i1 in range(ncfreq):
        i1max = i1
        if (freqvalues[i1] > highfreq):
            break
    print(' max Fourier coef at ', i1max,' is ',freqvalues[i1max],' Hz')

    #for i1 in range(ncfreq):
        #i1min = i1
        #if (freqvalues[i1] > lowfreq):
            #break

    i1min = 0
    print(' min Fourier coef at ', i1min,' is ',freqvalues[i1min],' Hz')



    resp = np.zeros((n2,n1))

    print(' ncfreq=',ncfreq)
    freq = ncfreq * df 
    period = (1.0/freq)/60.0

    print(' minimum period = ',period,' minutes')
    print(' maximum frequency = ',freq)
    print(' frequency increment = ',df)
    print(' frequency increment = ',df*1000000000,' nano-Hz')
    print (' fglobe buffer size=',ncfreq*npolarity*nlon)

    vorbit = 30000 # meters/second
    c = 299792458 # speed of light,  meters/second
    
   ############################
    #toffset = 100  ### positive number pushes event forward in time
   ############################

    print('****** toffset=',toffset)


######### shift and transpose respin to make resp #######################
#  shift all samples to make them line up with celestial zero

    for i2 in range(n2):
        for i1 in range(n1in-toffset):
            resp[i2,i1] = respin[i1+toffset,i2]

#########################################################################

    livestn = np.zeros(n2)
    for istn in range(n2):
        all_zeros = np.count_nonzero(respin[:,istn])
        if (all_zeros > 0):
            livestn[istn]  = 1.0

    if (year < 2000):

        #  live stations
        station_list1 = [1,2,3,5,7,8,10,11,12,13,15,16,17,19,20,22,23,24]
        #  best stations
        station_list2 = [2,3,5,7,10,11,12,13,15,16,20,23]
        #  one station
        station_list3 = [20,23]
        #  all stations
        station_list4 = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,
                         19,20,21,22,23,24]
        station_listX = [4,23]

        station_list = station_list2

##########    test    ##############
        #station_list = station_listX
##########    test    ##############


        print(' station list=',station_list)

        for istn in range(n2):
            livestn[istn]  = 0.0
            for istn2 in station_list:
                if (istn2-1 == istn):
                    livestn[istn]  = 1.0
    
    print(' live stations =',livestn)
        
    ncpua = os.cpu_count()
    print(' number of cpus available=',ncpua)
    print(' number of cpus to be used = ',ncpu)

    pltarray = np.zeros((nlat,nlon))
    footprintarray = np.zeros((nlat,nlon))



#        -- interpolation factor for Roemer correction

    if ( year < 2000):
        rsupersample = 10
    else:
        rsupersample = 6


            

    ### loop over source longitude and latitude from the table

#--- restart here if needed -----

    if (ilat1 < 0):
        ilat1 = 0
    if (ilat2 > nlat):
        ilat2 = nlat - 1
    print(' starting latitude reset to  = ',ilat1 )
    print(' ending latitude reset to  = ',ilat2 )

    for ilat in range( int(ilat1), int(ilat2+1) ):   

        print('Starting ilat=',ilat+1,' of ',nlat,'       ',datetime.datetime.now())

####  limit the output to a reasonable size
        ncfreqout = 120000 * padding
        fglobe=np.zeros((npolarity,nlon,ncfreqout),dtype=np.cdouble)
        
        inxarray = np.zeros([2,nlon],dtype=int)

        icnt = 0
        for ilon in range( nlon ) :

            inxarray[0,icnt] = ilat
            inxarray[1,icnt] = ilon
            icnt = icnt + 1

        dumarray = np.zeros(icnt,dtype=int)
        cnttable = dumarray.astype(np.int64)

        icnt = 0
        for ilon in range(nlon) :
            cnttable[icnt] = icnt
            icnt = icnt + 1

            
###  --- multi-cpu option ####
        if ( 1 == 1):
        
            with Pool(ncpu) as pp:

                longworkx = partial(longwork, \
                            resp,rsupersample,npolarity, \
                            longrid, latgrid, \
                            inxarray,df, \
                            gclat,elong,dt,n1,n2,nlon,nlat,\
                            livestn,year)

                q = pp.map(longworkx,cnttable)
        
            icnt= 0
            for ilon in range(nlon):

                globe,mxrm,wfootprint,deltapol =\
                  q[icnt]

                pltarray[ilat,ilon] = mxrm
                footprintarray[ilat,ilon] = wfootprint

                icnt = icnt + 1
        
                for ipol in range(npolarity):
                    rtemp = globe[ipol,:]
                    ftemp = np.fft.rfft(rtemp)
                    fglobe[ipol,ilon,0:ncfreqout] = ftemp[0:ncfreqout]
                
                # end of ipol loop

            # end of ilon loop


        
### --- save the results ####

 
        outfile = 'partial_ilat'+str(ilat)
        #print('Saving partial file =',outfile, '    ',datetime.datetime.now() )

        np.savez(outfile,\
             npolarity=npolarity,\
             fglobe=fglobe,\
             i1min=i1min, i1max=i1max, \
             nlat=nlat,nlon=nlon, padding=padding,\
             dt=dt,df=df,\
             n1=n1, n2=n2,ncfreq=ncfreq,\
             outfile=outfile,
             lat=lat,long=long, labels=labels,\
             longrid=longrid, latgrid=latgrid, \
             gclat=gclat,elong=elong, freq=freq, \
             year=year, deltapol=deltapol,\
             freqvalues=freqvalues,\
             footprintarray=footprintarray,\
             pltarray=pltarray )



    # end of ilat loop


    
    
    print('processing end time ----> ',datetime.datetime.now())

##### diagnostic plots #####
    #pltroemer(pltarray,year)
    pltfootprint(footprintarray,year)
    #plttempplot(tempplot,year)
    #plt.show()

    return




#-----------------------------------------------------------------------
        
""" Module longwork - parallel processing of longitude loop 
    inner loops
    Each call does one potential source position at a single ilat and ilon.
"""

def longwork(resp,rsupersample,npolarity, \
            longrid, latgrid, \
             inxarray, df, \
             gclat,elong,\
             dt,n1,n2,nlon,nlat,\
             livestn, year ,icount) :
    
    """
    parallel processing of longitude loop
    """
    
    ## source position ##

    ilat =      inxarray[0,icount]
    ilon =      inxarray[1,icount]




# *************************************************
# *************************************************
# *************************************************
# This is a comparison test between the original equatorial coords and galactic coords
# *************************************************
# *************************************************
# *************************************************


 ####      plot results in equatorial coordinates ####

    phi_s = latgrid[ilat]
    theta_s = longrid[ilon]

    #  used below
    a = phi_s
    cosa = np.cos(a)
    sina = np.sin(a)

   

    deltapol = (math.pi/2.0)/npolarity
    globe = np.zeros((npolarity,n1))

    if (year < 2000):
        iskip = 10    ##  increment between calculated weight values
    else:
        iskip = 20

#########################################################################

###  We need this for the Roemer correction
### ---- setup ----
    # from Meeus, Astronomical Algorithms - Chapter 13, eqns 13.1 and 13.2
    # convert from RA (theta_s) and Dec (phi_s) to ecliptic coordinates
    # using the pymeeus routines

    #dec = Angle(phi_s,radians=True)
    #ra = Angle(theta_s,radians=True)
    #dec = Angle(phi_s,radians=True)
    #ra = Angle(theta_s,radians=True)
    #lambda_sx, beta_sx = equatorial2ecliptical(ra, dec, epsilon) 
    ## ecliptical longitude 
    ## and latitude out

    ### fix the Roemer correction for J0806 ###

    dec_J0806 = Angle(8,6,22.95)
    ra_H0806 = Angle(15, 27, 31.0)
    epsilon = Angle(23.4392911)
    lambda_sx, beta_sx = equatorial2ecliptical(ra_H0806, dec_J0806, epsilon) 

    lambda_s = float(lambda_sx) * math.pi/180.0
    beta_s = float(beta_sx) * math.pi/180.0

    cosbeta = np.cos(beta_s)


    #  Roemer correction from Maggiore, Gravitational Waves, Vol. 1
    Omega = 2.0 * math.pi /( 365.256363004 * 24.0 * 60.0 * 60.0 )

#########################################################################

    yindex = np.zeros((n1))   # QC array
    x_shift_index = np.zeros((n1))

    vorbit = 30000 # meters/second
    c = 299792458 # speed of light,  meters/second
    
    wfootprint = 0.0


    for i1 in range(0,n1):   
        t = i1*dt
        # Roemer correction (Gravitational Waves, Maggiore)
        # 499.0048 from Meeus

        tRoemer= 0.0
#######################################################

        tshifted = t - tRoemer   # time in seconds
        isamp = int( rsupersample * tshifted/dt )  # time in samples
        if (isamp >= 0 and isamp < rsupersample * n1):
            x_shift_index[i1] = isamp 
        yindex[i1] = tRoemer   # QC array

        

    mxrm = np.amax(yindex)  # QC value for Roemer correction
    respR = np.zeros((n1))
  
    for i2 in range(n2) :
        ###if (livestn[i2] != 0.0 ):
        if (livestn[i2] > 0.0 ):



            for iii in range(n1):
                respR[iii] = resp[i2,iii]
                    
###############################################################


#        -- receiver latitude and longitude 
            phi_r = gclat[i2] # in radians
            theta_r = elong[i2]  # in radians

            poldirvals = np.zeros((npolarity,n1))
            WSindex =  np.zeros((n1))
            WSvalue =  np.zeros((n1))
            count_index  =  np.zeros((n1))

            WScnt = 0
    
            for i1 in range(0,n1):   
                t = i1*dt

                count_index[i1] = i1
    
                if (i1%iskip == 0):

                      # directional weight array
                      # eta is the angle change with the earth's rotation


                    eta = t * 2.0*math.pi/ 86164.09053083288
                    #  86164.09053083288 is rotation period 
                    #  of the earth in seconds
                    
                    # correct eta to the lowest angle
                    while eta > 2.0 * math.pi :
                        eta = eta - 2.0 * math.pi

                    thetaprime = theta_r + eta


                    C = thetaprime - theta_s
                    cosC = np.cos(C)
                    sinC = np.sin(C)

                    # used below
                    b=phi_r
                    sinb = np.sin(b)
                    cosb = np.cos(b)

                    ## see the cosine rule for spherical triangles
                    dist = np.arccos(sinb * sina + cosb * cosa * cosC)

                    # this doesn't matter much since we scan all the angles
                    az = np.arctan2(sinC, ( cosa*np.tan(b) ) - ( sina*cosC ) )
                    nu = dist
                    xpsi = az

                    # polarity analysis
                    WS2 = np.abs(np.sin(nu))**2

                    for ipol in range(npolarity):
                        polangle = ipol * deltapol
                        psip = xpsi + polangle
                        resp2 = (1+ 0.5 * np.sin( 2.0 * psip) )

                        poldirvals[ipol,WScnt] =  resp2

                    # end of ipol loop

                    WSindex[WScnt] = i1
                    WSvalue[WScnt] = WS2

                    WScnt = WScnt + 1


##############################################################################
    

                ## end of if (i1%iskip == 0) loop
            # end of i1 loop

#       --- interpolate the weights ---


            cs = CubicSpline(WSindex[0:WScnt], WSvalue[0:WScnt])
            Weights = cs(count_index)

            polweights = np.zeros((npolarity,n1))
            for ipol in range(npolarity):
                ppp = np.zeros((WScnt))
                ppp = poldirvals[ipol,:]
                cs = CubicSpline(WSindex[0:WScnt],ppp[0:WScnt])
                ppp2 = cs(count_index)
                polweights[ipol,:] = ppp2


#    -- apply the weights to the data ---


            for i1 in range(0,n1):
                wfootprint = wfootprint + Weights[i1]
                for ipol in range(npolarity):
                    A2 = respR[i1] * Weights[i1] * polweights[ipol,i1]
                    globe[ipol,i1] = globe[ipol,i1] + A2
    
            # end of i1 loop
        # end of if (if (livestn[i2] != 0.0 ):
    # end of i2 loop
        
    return globe,mxrm,wfootprint,deltapol
            
#-----------------------------------------------------------------------
def pltroemer(pltarray,year) :

    """
    plot the Roemer correction
    """


    #print(' Saving partial file')
    outfile = 'plotaa'
    print('Saving plot data file =',outfile, '    ',datetime.datetime.now() )

    np.savez(outfile, pltarray=pltarray)

    print('Saved plot file =',outfile, '    ',datetime.datetime.now() )



    (nlon,nlat) = np.shape(pltarray)
    print(' nlon = ',nlon)
    print(' nlat = ',nlat)
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='mollweide')

    lon = np.linspace(-np.pi, np.pi,nlat)
    lat = np.linspace(-np.pi/2., np.pi/2.,nlon)
    Lon,Lat = np.meshgrid(lon,lat)

    im = ax.pcolormesh(Lon,Lat,pltarray, cmap=plt.cm.jet,shading='auto')
    fig.colorbar(im)
    plt.title('Roemer correction')

    plotname='Roemer_correction'+str(year)+'-resp.pdf'
    plt.savefig(plotname)


    #plt.show()



    return
    
    
#-----------------------------------------------------------------------
#-----------------------------------------------------------------------
def plttempplot(pltarray,year) :

    """
    plot the acquisition footprint
    """


    fig = plt.figure()
    plt.plot(pltarray)
    plt.title('tempplot_'+str(year))
    plotname='C_tempplot'+str(year)+'-resp.tiff'
    plt.savefig(plotname)

    #plt.show()

    return


#-----------------------------------------------------------------------
def pltfootprint(pltarray,year) :

    """
    plot the acquisition footprint
    """


    print(' Saving footprint file')
    outfile = 'footprint'+str(year)+'_X'
    print('Saving plot data file =',outfile, '    ',datetime.datetime.now() )

    np.savez(outfile, pltarray=pltarray)

    print('Saved plot file =',outfile, '    ',datetime.datetime.now() )



    (nlon,nlat) = np.shape(pltarray)
    print(' nlon = ',nlon)
    print(' nlat = ',nlat)
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='mollweide')

    lon = np.linspace(-np.pi, np.pi,nlat)
    lat = np.linspace(-np.pi/2., np.pi/2.,nlon)
    #Lon,Lat = np.meshgrid(lon,lat)

    #im = ax.pcolormesh(Lon,Lat,pltarray, cmap=plt.cm.jet,shading='auto')
    im = ax.pcolormesh(lon,lat,pltarray, cmap=plt.cm.jet,shading='auto')
    fig.colorbar(im)
    plt.title('Footprint')

    plotname='footprint'+str(year)+'-resp.pdf'
    plt.savefig(plotname)


    #plt.show()
    
    return


            
#-----------------------------------------------------------------------

def pltsky(pltarray,year,title) :

    """
    plot the acquisition footprint
    """

    (nlat,nlon) = np.shape(pltarray)
    print(' nlat = ',nlat)
    print(' nlon = ',nlon)
    fig = plt.figure()
    #ax = fig.add_subplot(111, projection='mollweide')

    #lat = np.linspace(-np.pi/2.0, np.pi/2.0,nlat)
    #lon = np.linspace(-np.pi, np.pi,nlon)
    #im = ax.pcolormesh(lon,lat,pltarray, cmap=plt.cm.jet,shading='auto')
    #fig.colorbar(im)
    plt.imshow(pltarray)
    plt.title(title)

    plotname='ABsky'+str(year)+'_'+title+'-newresp.pdf'
    plt.savefig(plotname)


    plt.show()



#-----------------------------------------------------------------------


""" Module asetup - setup 
    set locations of stations
"""

def asetup2000(year,names,n2) :
    
    """
    Separate the overlapping sources.
    niter is the number of iterations to use to solve the separation.
    """

##
## get the the longitude and latitude of the uniformly spaced grid
## 4 degree incrments
## now 6 degree increments


    global gclat
    global elong

    diag = 0
    
## set the number of correlations to test
    deltaangle = 6.0
    npolarity = 9
    
    
    
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

###  get station locations and names
                     
    lat,long, labels = stations2000(n2,names)


#   convert lat and longs to radians
    gclat = np.zeros(n2)
    elong = np.zeros(n2)

    for i in range(n2) :
        s = lat[i]/np.abs(lat[i])    ## sign of the latitude
        w = 0.0      
        if lat[i] != -90 :  # for stations not at the South Pole
            w = long[i]/np.abs(long[i])

#     ### for the 2000s, the latitudes and longitudes are in degrees
        gclat[i] = lat[i]
        elong[i] = long[i]
        


##### QC for plotting the station locations ####
    if 1 == 2 :
        fig = plt.figure()
        plt.plot(elong,gclat,'ro')
        plt.title('IDA Station Locations - Degrees')
        for ii in range(n2):
            plt.text(elong[ii],gclat[ii],labels[ii])
        plt.show()

    for i in range(n2) :   ## convert to radians
            gclat[i] = gclat[i] * math.pi /180.0
            elong[i] = elong[i] * math.pi /180.0
       
    nlat = round(180.0/deltaangle)+1
    nlon = round(360.0/deltaangle)+1
   
    latgrid = np.zeros(nlat)
    longrid = np.zeros(nlon)
   
    for ilat in range(nlat):
        latitude = ilat * deltaangle - 90.0 + 0.5
        latitude = (latitude / 180.0 ) * np.pi
        latgrid[ilat] = latitude
       
    for ilon in range(nlon):
        longitude = ilon * deltaangle - 180.0 + 0.5
        longitude = (longitude / 180.0 ) * np.pi
        longrid[ilon] = longitude


    return lat,long,labels,latgrid,longrid,nlat,nlon,\
npolarity,deltaangle,gclat,elong


## end of asetup2000
#-----------------------------------------------------------------------


""" Module asetup - setup 
    set locations of stations
"""

def asetup(year,n2) :
    
    """
    Separate the overlapping sources.
    niter is the number of iterations to use to solve the separation.
    """

##
## get the the longitude and latitude of the uniformly spaced grid
## 4 degree incrments
## now 6 degree increments


    global gclat
    global elong

    diag = 0
    
## set the number of correlations to test
    deltaangle = 6.0
    npolarity = 9
    
    print(' n2=',n2)
    print(' ')

    

###  get station locations and names
                     
    lat,long, labels = stations()


#   convert lat and longs to radians
    gclat = np.zeros(n2)
    elong = np.zeros(n2)

    for i in range(n2) :
        s = lat[i,0]/np.abs(lat[i,0])    ## sign of the latitude
        w = 0.0      
        if lat[i,0] != -90 :  # for stations not at the South Pole
            w = long[i,0]/np.abs(long[i,0])

        gclat[i] = lat[i,0]+ s* (( lat[i,1] +   ( lat[i,2] /60.0 ) )/ 60.0)
        elong[i] = long[i,0]+ w*((long[i,1] +   (long[i,2]/60.0  ) )/ 60.0)
        


######  QC plot of station locations   ######
    #if 1 == 1 :
        #fig = plt.figure()
        #plt.plot(elong,gclat,'ro')
        #plt.title('IDA Station Locations - Degrees')
        #for ii in range(n2):
        #    plt.text(elong[ii],gclat[ii],labels[ii])
        #plt.show()

    for i in range(n2) :   ## convert to radians
            gclat[i] = gclat[i] * math.pi /180.0
            elong[i] = elong[i] * math.pi /180.0
       
    nlat = round(180.0/deltaangle)+1
    nlon = round(360.0/deltaangle)+1
   
    latgrid = np.zeros(nlat)
    longrid = np.zeros(nlon)
   
    for ilat in range(nlat):
        latitude = ilat * deltaangle - 90.0 + 0.5
        latitude = (latitude / 180.0 ) * np.pi
        latgrid[ilat] = latitude
       
    for ilon in range(nlon):
        longitude = ilon * deltaangle - 180.0 + 0.5
        longitude = (longitude / 180.0 ) * np.pi
        longrid[ilon] = longitude


    return lat,long,labels,latgrid,longrid,nlat,nlon,\
npolarity,deltaangle,gclat,elong


## end of asetup
#-----------------------------------------------------------------------


""" Module stations 
    set locations and labels of stations
"""

def stations2000(n2,names) :
    
    """
    Fill in the locations (lat, long) of the IDA stations.
    """

    lat = np.zeros(n2)
    long = np.zeros(n2)

    stnlocs = [
    ['AAK',	42.6375,	74.4942	 ],
    ['ABKT',	37.9304,	58.1189	 ],
    ['ABPO',	-19.018,	47.229	 ],
    ['ALE',	82.5033,	-62.35	 ],
    ['ARTI',	56.3879,	58.3849	 ],
    ['ARU',	56.4302,	58.5625	 ],
    ['ASCN',	-7.9327,	-14.3601	], 
    ['BFO',	48.3301,	8.3296	 ],
    ['BORG',	64.7474,	-21.3268	], 
    ['BORK',	53.0461,	70.3184	 ],
    ['BRVK',	53.0581,	70.2828	 ],
    ['CMLA',	37.7637,	-25.5243	], 
    ['COCO',	-12.1901,	96.8349	 ],
    ['DGAR',	-7.4121,	72.4525	 ],
    ['EFI',	-51.6753,	-58.0637	 ],
    ['ERM',	42.015,	143.1572	], 
    ['ESK',	55.3167,	-3.205	 ],
    ['FFC',	54.725,	-101.9783	], 
    ['GAR',	39.0052,	70.3328	 ],
    ['HOPE',	-54.2836,	-36.4879	 ],
    ['IASL',	34.946201,	-106.456703	 ],
    ['IBFO',	48.331902,	8.3311	 ],
    ['JTS',	10.2908,	-84.9525	 ],
    ['KAPI',	-5.0142,	119.7517	 ],
    ['KDAK',	57.7828,	-152.5835	 ],
    ['KIV',	43.9562,	42.6888	 ],
    ['KURK',	50.7154,	78.6202	 ],
    ['KWAJ',	8.8019,	167.613	 ],
    ['KWJN',	9.2873,	167.5369	], 
    ['LVZ',	67.8979,	34.6514	 ],
    ['MBAR',	-0.6019,	30.7382	 ],
    ['MSEY',	-4.6737,	55.4792	 ],
    ['MSVF',	-17.7448,	178.0528	 ],
    ['NIL',	33.6506,	73.2686	 ],
    ['NNA',	-11.9875,	-76.8422	 ],
    ['NRIL',	69.5049,	88.4414	 ],
    ['NVS',	54.8404,	83.2346	 ],
    ['OBN',	55.1146,	36.5674	 ],
    ['PALK',	7.2728,	80.7022	 ],
    ['PFO',	33.6092,	-116.4553	], 
    ['RAYN',	23.5225,	45.5032	 ],
    ['RPN',	-27.1267,	-109.3344	 ],
    ['SACV',	14.9702,	-23.6085	 ],
    ['SHEL',	-15.9594,	-5.7455	 ],
    ['SIMI',	38.6585,	69.0083	 ],
    ['SUR',	-32.3797,	20.8117	 ],
    ['TAU',	-42.9099,	147.3204	], 
    ['TLY',	51.6807,	103.6438	 ],
    ['UOSS',	24.9453,	56.2042	 ],
    ['WRAB',	-19.9336,	134.36	 ],
    ['XBFO',	48.3301,	8.3296	 ],
    ['XPF',	33.6092,	-116.4533	],
    ['XPFO',	33.6107,	-116.4555	 ]
    ]
    
    labels=["     "]*n2

    for i in range(0,n2):
        for j in range(53):
            if ( names[i] == stnlocs[j][0]):
                lat[i] = stnlocs[j][1]
                long[i] = stnlocs[j][2]
                labels[i] = names[i]
        if (labels[i] == "     "):
            print(' station not found ------')
            print(' station not found ------')
            print(' station not found ------')
            print(' station not found ------')
            print(' station not found ------')
            print(' names =',names)
            print(' stnlocs  =',stnlocs[:,0])
            quit()

    print(' labels = ',labels)




##### QC plot of station locations  #####
    if 1 == 2 :
        fig = plt.figure()
        #ax = fig.add_subplot(111, projection='mollweide')
        tlong = long[:,0]
        tlat = lat[:,0]
        plt.plot(tlong,tlat,'ro')
        plt.title('IDA Station Locations - Degrees')
        for ii in range(24):
            xx = float(long[ii,0])
            yy = float(lat[ii,0])
            plt.text(xx,yy,labels[ii])
        plt.show()




    return lat, long, labels

#  end of stations2000
#-----------------------------------------------------------------------
#-----------------------------------------------------------------------


""" Module stations 
    set locations and labels of stations
"""

def stations() :
    
    """
    Fill in the locations (lat, long) of the IDA stations.
    """
    
    ### station locations and names

    lat=np.array([[82,29,0],
    [-15,39,50], 
    [40,2,25],
    [-35,19,15], 
    [64,51,36],
    [-27,9,29], 
    [42,0,54], 
    [55,19,0], 
    [39,0,0], 
    [13,32,18], 
    [44,38,16],
    [21,25,24], 
    [25,8,54],
    [-77,50,57],
    [-11,59,15], 
    [33,36,33],
    [-21,12,45],
    [-4,36,54], 
    [18,6,34],
    [-90,0,0], 
    [45,16,45],
    [-32,22,47],
    [-35,1,57],
    [-21,11,44]])


    long = np.array([[ -62,24,0], 
    [-47,54,12], 
    [116,10,30], 
    [148,59,55],
    [-147,50,6],
    [-109,26,4], 
    [143,9,26], 
    [-3,12,18], 
    [70,19,0], 
    [144,54,42], 
    [-63,35,30],
    [-158,0,54], 
    [102,44,49],
    [166,40,2],
    [-76,50,32],
    [-116,27,19],
    [-159,46,24],
    [ 55,29,27], 
    [-66,9,0], 
    [0,0,0], 
    [ 4,32,31], 
    [ 20,48,42],
    [ 138,34,41],
    [ 55,34,40]])
   

    labels=['1 ALE','2 BDF','3 BJT','4 CAN','5 CMO','6 EIC','7 ERM','8 ESK','9 GAR','10 GUA','11 HAL','12 KIP','13 KMY','14 MCM','15 NNA','16 PFO','17 RAR','18 SEY','19 SJG','20 SPA','21 SSB','22 SUR','23  TWO','24 PCR']


    if 1 == 2 :
        fig = plt.figure()
        #ax = fig.add_subplot(111, projection='mollweide')
        tlong = long[:,0]
        tlat = lat[:,0]
        plt.plot(tlong,tlat,'ro')
        plt.title('IDA Station Locations - Degrees')
        for ii in range(24):
            xx = float(long[ii,0])
            yy = float(lat[ii,0])
            plt.text(xx,yy,labels[ii])
        plt.show()


    return lat, long, labels
    
#-----------------------------------------------------------------------

### Julian dates from https://aa.usno.navy.mil/data/JulianDate
### also http://www.csgnetwork.com/siderealjuliantimecalc.html for Sidereal times

def get_sidereal_time(year):

    jd1984 = 2445700.501296  ### this is the reference times for the start of day -- unused ###
     
    if ( year == int(1984)):
        dtime = 0.0
        stimehr = 6
        stimemin = 39
        stimesec =4.448052040522015
        
    elif (year == 1985):
        dtime = 2446066.501296 - jd1984
        stimehr = 6
        stimemin = 41
        stimesec = 3.702126566419537
        
    elif ( year == 1986):
        dtime = 2446431.501296 - jd1984
        stimehr = 6
        stimemin = 41
        stimesec = 23.800880672833955
                
    elif (year == 1987):
        dtime = 2446796.501296 - jd1984
        stimehr = 6
        stimemin = 48
        stimesec = 4.448052040522015
        
                
    elif ( year == 2017):
        dtime = 2446431.501296 - jd1984
        stimehr = 6
        stimemin = 40
        stimesec = 26.499653337714335
               
    else:
        print(' Julian date needs setting for year=',year)
        sys.exit(9999)
        
    
    siderealtime = stimehr * 60 * 60 + stimemin * 60 + stimesec   ### time in seconds
    
              
    return siderealtime
    



#-----------------------------------------------------------------------

if __name__ == '__main__':
    print(' time start=', time.asctime() )
    runit()
    print(' time end=', time.asctime() )
    print(' @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@=' )
