#Qblock_freq_v03.py

import numpy as np      
import datetime
import sys
import time


""" Module blockit
    cut the analysis and merge them
"""

#------------------------------------------------------------------------
def blockit() :
    
    seconds0 = time.time()

    istart = int(sys.argv[1])
    print(' starting frequency index=',istart)

    brun(istart)

    secondsn = time.time()
    print(' run time = ',secondsn-seconds0)

    return


    
""" Module brun
    block the analysis
"""

def brun(istart):
    
    """
    Block the Rotated Fourier transform responses
    """
    
    ###  get first record with the required parameters

    ilat = 0
    if 1 == 1:
        print('extracting ilat=',ilat+1,'   ',datetime.datetime.now())
        tempfile = 'partial_ilat'+str(ilat)+'.npz'
        print(tempfile)
        npzfile = np.load(tempfile)
        fglobe = npzfile['fglobecorrected']
        if (ilat == 0):
            npolarity = npzfile['npolarity']
            nlat =  npzfile['nlat']
            nlon =   npzfile['nlon']
            dt = npzfile['dt']
            df = npzfile['df']
            n1 = npzfile['n1']
            n2 = npzfile['n2']
            ncfreq = npzfile['ncfreq']
            outfile = npzfile['outfile']
            lat = npzfile['lat']
            long = npzfile['long']
            labels = npzfile['labels']
            longrid = npzfile['longrid']
            latgrid = npzfile['latgrid']
            gclat = npzfile['gclat']
            elong = npzfile['elong']
            year = npzfile['year']
            i1min = npzfile['i1min']
            i1max = npzfile['i1max']
            ncfreq = npzfile['ncfreq']
            freqvalues = npzfile['freqvalues']


            print( ' year=',year,' -------------------------')
            print( ' istart=',istart)
            print( ' i1min=',i1min)
            print( ' i1max=',i1max)

            print('npolarity =',npolarity)
            print(' nlat =',nlat,' nlon =',nlon)
            print (' fglobe buffer size=',ncfreq*npolarity*nlon)
            print(' shape of fglobe=',np.shape(fglobe))
            
            iend =  istart + 50000
            if (iend > i1max):
                iend = i1max
            print(' istart=',istart,'  iend=',iend)

            if (istart < i1min):
                print(' start of frequencies ',istart,' less that first freq ',i1min)
                sys.exit(1)  ## error exit

            if ( iend < istart):
                print(' end of frequencies ',iend,' past the start value ',istart)
                sys.exit(1)  ## error exit


            print(' min freq =',istart*df,' max freq=',iend*df)

            if (iend == 0.0):
                minper = 1.0/df
            else:
                minper = 1.0/(iend*df)

            if (istart == 0.0):
                maxper = 1.0/df
            else:
                maxper = 1.0/(iend*df)

            print(' min period=',minper,' max period=',1.0/maxper)
            ncutfreq = iend - istart + 1
            cglobe = np.zeros((npolarity,nlon,nlat,ncutfreq),dtype=complex)

            #outfile = '/Users/raymondabma/Documents/2011/Block'
            outfile = 'Block'
            print(' output file =',outfile)
            print(' ')

            cglobe[:,:,ilat,1:ncutfreq] = fglobe[:,:,istart-i1min:iend-i1min]

              
    ### loop over source longitude and latitude from the table
    for ilat in range(1,nlat):
        print('extracting ilat=',ilat+1,' of ',nlat,'    ',datetime.datetime.now())
        tempfile = 'partial_ilat'+str(ilat)+'.npz'
        #print(tempfile)
        npzfile = np.load(tempfile)
        fglobe = npzfile['fglobecorrected']

        cglobe[:,:,ilat,1:ncutfreq] = fglobe[:,:,istart-i1min:iend-i1min]

    # end of ilat loop

    print(' writing output file  ', outfile)
    np.savez(outfile,\
         cglobe=cglobe,npolarity=npolarity,\
         nlat=nlat,nlon=nlon,\
         dt=dt,df=df,\
         n1=n1, n2=n2,ncfreq=ncfreq,\
         istart=istart,iend=iend,\
         lat=lat,long=long,labels=labels,\
         longrid=longrid,latgrid=latgrid,\
         gclat=gclat,elong=elong, \
         i1min=i1min, i1max=i1max, \
         freqvalues=freqvalues,\
         year=year )

    
    
    print('          ',datetime.datetime.now())
    print(' df=== ',df)
    

    return


#-----------------------------------------------------------------------

print(' time start=', time.asctime() )
blockit()
print(' time end=', time.asctime() )
