#!/bin/csh -fx

### run all scanning jobs for all directories

cd GW9_4

cd GW1984
../Programs/run_blocksA.csh
cd ..

cd GW1985
../Programs/run_blocksA.csh
cd ..

cd GW1986
../Programs/run_blocksA.csh
cd ..

cd GW1987
../Programs/run_blocksA.csh
cd ..

cd GW2017
../Programs/run_blocksA.csh
cd ..

cd ..

