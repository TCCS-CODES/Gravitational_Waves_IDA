#!/bin/csh -fx

### run all scanning jobs for all directories

cd Figures-synth

./Fig6AB_sine_summed_020.001.py 1
./Fig6AB_sine_summed_e-09.py 1
./Fig6AB_sine_summed_e-10.py 1

./sig_noise_5v0.5_v04.py

cp Fig6AB_summed_150_sine_v020.001.pdf ../Figures/.
cp Fig6AB_summed_150_sine_v021e-09.pdf ../Figures/.
cp Fig6AB_summed_150_sine_v021e-10.pdf ../Figures/.

cp both-5-0.5-v04.pdf ../Figures/.

cd ..

cd ..

