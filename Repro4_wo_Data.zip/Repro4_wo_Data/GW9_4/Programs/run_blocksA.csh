#!/bin/csh -f

### 90000 includes J0806

set j = 90000
while ($j < 90001)
 echo $j
 python3 ../Programs/block_freq_v04A.py $j
 mv Block.npz SBlock_${j}.npz
 @ j = $j + 50000
end
