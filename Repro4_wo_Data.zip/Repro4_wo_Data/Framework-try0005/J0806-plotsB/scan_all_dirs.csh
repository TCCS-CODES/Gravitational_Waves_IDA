#!/bin/csh -fx

./J0806_center_v08D.py

./J0806_center_v08DX.py

./J0806_horizontal_v08DX.py

cp *pdf ../../Figures
