#!/bin/csh -fx

### fix scanning jobs for all directories

cd GW9_4
./change_ncpu_all.csh
cd ..
