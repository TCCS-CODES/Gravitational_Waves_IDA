#!/bin/csh -fx

### run all scanning jobs for all directories



./block_M31_dirs.csh
