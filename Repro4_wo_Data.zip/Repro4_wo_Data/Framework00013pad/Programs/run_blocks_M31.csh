#!/bin/csh -f

### M31


set j=136000
#set j = 170000
#set j = 340000
while ($j < 136001)
 echo $j
 python3 ../Programs/block_freq_v06.py $j 2000
 mv Block.npz SBlock_${j}.npz
 @ j = $j + 2000
end
